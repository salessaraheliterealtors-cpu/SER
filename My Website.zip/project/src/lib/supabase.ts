import { createClient, type SupabaseClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || '';
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || '';

export const isSupabaseConfigured = Boolean(supabaseUrl && supabaseAnonKey);

export const supabase: SupabaseClient = isSupabaseConfigured
  ? createClient(supabaseUrl, supabaseAnonKey)
  : (null as unknown as SupabaseClient);

export type PropertyRow = {
  id: string;
  name: string;
  location: string;
  status: string;
  config: string;
  bhk: string;
  furnishing: string;
  carpet_area: string;
  parking: string;
  description: string;
  price: string;
  image_url: string;
  gallery_urls: string[];
  video_url: string;
  photo_folder_url: string;
  video_link_url: string;
  transaction_type: string | null;
  created_at: string;
  updated_at: string;
};
