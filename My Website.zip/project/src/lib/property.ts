export type TransactionType = 'Buy' | 'Rent' | 'Sell';

export const TRANSACTION_TYPES: TransactionType[] = ['Buy', 'Rent', 'Sell'];

export function normalizeImageUrl(url: string | undefined | null): string {
  if (!url || typeof url !== 'string') return '';
  const trimmed = url.trim();
  if (!trimmed) return '';
  const driveId = trimmed.match(/drive\.google\.com\/(?:file\/d\/|open\?id=|uc\?(?:export=\w+&)?id=)([a-zA-Z0-9_-]+)/);
  if (driveId) return `https://drive.google.com/thumbnail?id=${driveId[1]}&sz=w1600`;
  if (/^https?:\/\//i.test(trimmed) || trimmed.startsWith('/')) return trimmed;
  return '';
}

export function parsePriceValue(priceStr: string): number | null {
  if (!priceStr || typeof priceStr !== 'string') return null;
  const text = priceStr.trim();
  if (!text) return null;
  const lower = text.toLowerCase();
  const numericMatch = lower.match(/(\d+(?:,\d{2,3})*(?:\.\d+)?)/);
  if (!numericMatch) return null;
  const rawNumber = Number.parseFloat(numericMatch[1].replace(/,/g, ''));
  if (Number.isNaN(rawNumber)) return null;

  const crore = lower.includes('cr') || lower.includes('crore');
  const lakh = lower.includes('lakh') || lower.includes('lac') || lower.includes('lacs');
  if (crore) return rawNumber * 100;
  if (lakh) return rawNumber;
  if (rawNumber >= 100) return rawNumber;
  if (rawNumber >= 1) return rawNumber * 100;
  return rawNumber;
}

export function budgetFilterCr(budget: string): { min: number; max: number } | null {
  switch (budget) {
    case '₹ 2–5 Cr':
      return { min: 200, max: 500 };
    case '₹ 5–10 Cr':
      return { min: 500, max: 1000 };
    case '₹ 10 Cr+':
      return { min: 1000, max: Infinity };
    default:
      return null;
  }
}
