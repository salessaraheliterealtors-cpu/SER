import type { TransactionType } from '@/data';
import { supabase, isSupabaseConfigured, type PropertyRow } from '@/lib/supabase';
import { normalizeImageUrl } from '@/lib/property';
import { assignSlugs } from '@/lib/slug';
import { isAvailableStatus } from '@/lib/availability';

export type PropertyDetail = {
  id: string;
  name: string;
  location: string;
  image: string;
  status: string;
  config: string;
  description: string;
  price: string;
  bhk: string;
  furnishing: string;
  carpetArea: string;
  parking: string;
  galleryUrls: string[];
  videoUrl: string;
  photoFolderUrl: string;
  videoLinkUrl: string;
  transactionType: TransactionType | null;
  slug: string;
};

export function fromRow(row: PropertyRow, slug: string): PropertyDetail {
  const rawGallery = Array.isArray(row.gallery_urls) ? row.gallery_urls : [];
  return {
    id: row.id,
    name: row.name,
    location: row.location,
    image: normalizeImageUrl(row.image_url),
    status: row.status || '',
    config: row.config || '',
    description: row.description || '',
    price: row.price || '',
    bhk: row.bhk || '',
    furnishing: row.furnishing || '',
    carpetArea: row.carpet_area || '',
    parking: row.parking || '',
    galleryUrls: rawGallery.map(normalizeImageUrl).filter(Boolean),
    videoUrl: row.video_url || '',
    photoFolderUrl: row.photo_folder_url || '',
    videoLinkUrl: row.video_link_url || '',
    transactionType: (['Buy', 'Rent', 'Sell'].includes(row.transaction_type || '') ? (row.transaction_type as TransactionType) : null),
    slug,
  };
}

export async function fetchAllProperties(): Promise<{ properties: PropertyDetail[]; loadFailed: boolean }> {
  if (!isSupabaseConfigured) {
    return { properties: [], loadFailed: true };
  }
  const { data, error } = await supabase.from('properties').select('*').order('created_at', { ascending: false });
  if (error || !data) {
    return { properties: [], loadFailed: true };
  }
  const slugs = assignSlugs(data);
  const available: PropertyDetail[] = [];
  data.forEach((row, index) => {
    if (isAvailableStatus(row.status)) available.push(fromRow(row, slugs[index]));
  });
  return { properties: available, loadFailed: false };
}

export function findPropertyBySlug(props: PropertyDetail[], slug: string): PropertyDetail | null {
  return props.find((p) => p.slug === slug) || null;
}

export function getDriveFolderEmbed(url: string): string | null {
  if (!url || typeof url !== 'string') return null;
  const match = url.match(/drive\.google\.com\/drive\/folders\/([a-zA-Z0-9_-]+)/);
  if (match) return `https://drive.google.com/drive/folders/${match[1]}?usp=sharing`;
  return null;
}

export function getVideoEmbed(url: string): string | null {
  if (!url || typeof url !== 'string') return null;
  const driveMatch = url.match(/drive\.google\.com\/file\/d\/([a-zA-Z0-9_-]+)/);
  if (driveMatch) return `https://drive.google.com/file/d/${driveMatch[1]}/preview`;
  const ytMatch = url.match(/(?:youtube\.com\/watch\?v=|youtu\.be\/)([a-zA-Z0-9_-]+)/);
  if (ytMatch) return `https://www.youtube.com/embed/${ytMatch[1]}`;
  return null;
}
