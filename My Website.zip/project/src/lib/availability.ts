const UNAVAILABLE_STATUSES = new Set(['sold', 'leased', 'rented', 'unavailable', 'archived']);

export function isAvailableStatus(status: string | null | undefined): boolean {
  return !UNAVAILABLE_STATUSES.has((status ?? '').trim().toLowerCase());
}
