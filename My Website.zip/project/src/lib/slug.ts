export function slugify(name: string, location: string): string {
  const base = `${name} ${location}`
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9\s-]/g, '')
    .replace(/\s+/g, '-')
    .replace(/-+/g, '-')
    .replace(/^-|-$/g, '');
  return base || 'property';
}

// Units can share a name and location, so colliding rows get a suffix from their stable id.
export function assignSlugs(rows: { id: string; name: string; location: string }[]): string[] {
  const bases = rows.map((row) => slugify(row.name, row.location));
  const counts = new Map<string, number>();
  for (const base of bases) counts.set(base, (counts.get(base) ?? 0) + 1);
  return rows.map((row, index) => ((counts.get(bases[index]) ?? 0) > 1 ? `${bases[index]}-${row.id.slice(0, 8)}` : bases[index]));
}
