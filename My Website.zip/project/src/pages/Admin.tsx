import { useEffect, useState, type ChangeEvent, type FormEvent } from 'react';
import { ArrowRight, Check, FolderOpen, Image as ImageIcon, Link as LinkIcon, Loader2, Lock, LogOut, Trash2, Upload, Video, X } from 'lucide-react';
import { Link } from 'react-router-dom';
import { supabase, isSupabaseConfigured, type PropertyRow } from '@/lib/supabase';
import { useDocumentMeta } from '@/hooks/useDocumentMeta';
import { useAdminSession } from '@/hooks/useAdminSession';
import AdminSignIn from '@/components/AdminSignIn';

const emptyForm: Omit<PropertyRow, 'id' | 'created_at' | 'updated_at'> = {
  name: '',
  location: '',
  status: 'Featured',
  config: '',
  bhk: '',
  furnishing: 'Fully Furnished',
  carpet_area: '',
  parking: '',
  description: '',
  price: 'Price on Request',
  image_url: '',
  gallery_urls: [],
  video_url: '',
  photo_folder_url: '',
  video_link_url: '',
  transaction_type: '',
};

type UploadState = 'idle' | 'uploading' | 'done' | 'error';

function Admin() {
  const [properties, setProperties] = useState<PropertyRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [form, setForm] = useState({ ...emptyForm });
  const [saving, setSaving] = useState(false);
  const [savedMsg, setSavedMsg] = useState('');
  const [heroUpload, setHeroUpload] = useState<UploadState>('idle');
  const [galleryUploads, setGalleryUploads] = useState<UploadState>('idle');
  const [videoUpload, setVideoUpload] = useState<UploadState>('idle');
  const { session, loading: sessionLoading } = useAdminSession();

  useDocumentMeta({
    title: 'Admin',
    description: 'Property management panel for Sarah Elite Realtors listings.',
    path: '/admin',
    noindex: true,
  });

  const ADMIN_WRITES_ENABLED = false;
  const writeDisabled = !ADMIN_WRITES_ENABLED || !isSupabaseConfigured;

  useEffect(() => {
    fetchProperties();
  }, []);

  async function fetchProperties() {
    if (!isSupabaseConfigured) {
      setLoading(false);
      return;
    }
    setLoading(true);
    const { data, error } = await supabase.from('properties').select('*').order('created_at', { ascending: false });
    if (error) {
      console.error(error);
    } else {
      setProperties(data || []);
    }
    setLoading(false);
  }

  function resetForm() {
    setForm({ ...emptyForm });
    setEditingId(null);
    setHeroUpload('idle');
    setGalleryUploads('idle');
    setVideoUpload('idle');
    setSavedMsg('');
  }

  function startEdit(prop: PropertyRow) {
    setEditingId(prop.id);
    setForm({
      name: prop.name,
      location: prop.location,
      status: prop.status,
      config: prop.config,
      bhk: prop.bhk,
      furnishing: prop.furnishing,
      carpet_area: prop.carpet_area,
      parking: prop.parking,
      description: prop.description,
      price: prop.price,
      image_url: prop.image_url,
      gallery_urls: prop.gallery_urls || [],
      video_url: prop.video_url || '',
      photo_folder_url: prop.photo_folder_url || '',
      video_link_url: prop.video_link_url || '',
      transaction_type: prop.transaction_type || '',
    });
    setSavedMsg('');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  async function uploadFile(file: File, folder: string): Promise<string | null> {
    const ext = file.name.split('.').pop();
    const fileName = `${folder}/${Date.now()}-${Math.random().toString(36).slice(2)}.${ext}`;
    const { error } = await supabase.storage.from('property-media').upload(fileName, file, { cacheControl: '3600', upsert: false });
    if (error) {
      console.error(error);
      return null;
    }
    const { data: urlData } = supabase.storage.from('property-media').getPublicUrl(fileName);
    return urlData.publicUrl;
  }

  async function handleHeroUpload(e: ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    setHeroUpload('uploading');
    const url = await uploadFile(file, 'hero');
    if (url) {
      setForm((f) => ({ ...f, image_url: url }));
      setHeroUpload('done');
    } else {
      setHeroUpload('error');
    }
  }

  async function handleGalleryUpload(e: ChangeEvent<HTMLInputElement>) {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    setGalleryUploads('uploading');
    const urls: string[] = [];
    for (const file of Array.from(files)) {
      const url = await uploadFile(file, 'gallery');
      if (url) urls.push(url);
    }
    if (urls.length > 0) {
      setForm((f) => ({ ...f, gallery_urls: [...f.gallery_urls, ...urls] }));
      setGalleryUploads('done');
    } else {
      setGalleryUploads('error');
    }
  }

  async function handleVideoUpload(e: ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    setVideoUpload('uploading');
    const url = await uploadFile(file, 'videos');
    if (url) {
      setForm((f) => ({ ...f, video_url: url }));
      setVideoUpload('done');
    } else {
      setVideoUpload('error');
    }
  }

  function removeGalleryImage(idx: number) {
    setForm((f) => ({ ...f, gallery_urls: f.gallery_urls.filter((_, i) => i !== idx) }));
  }

  async function handleSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (writeDisabled || saving) return;
    setSaving(true);
    setSavedMsg('');

    const payload = {
      name: form.name,
      location: form.location,
      status: form.status,
      config: form.config,
      bhk: form.bhk,
      furnishing: form.furnishing,
      carpet_area: form.carpet_area,
      parking: form.parking,
      description: form.description,
      price: form.price,
      image_url: form.image_url,
      gallery_urls: form.gallery_urls,
      video_url: form.video_url,
      photo_folder_url: form.photo_folder_url,
      video_link_url: form.video_link_url,
      transaction_type: form.transaction_type || null,
    };

    if (editingId) {
      const { error } = await supabase.from('properties').update(payload).eq('id', editingId);
      if (error) {
        setSavedMsg('Error updating property. Please try again.');
      } else {
        setSavedMsg('Property updated successfully.');
        resetForm();
        fetchProperties();
      }
    } else {
      const { error } = await supabase.from('properties').insert(payload);
      if (error) {
        setSavedMsg('Error adding property. Please try again.');
      } else {
        setSavedMsg('Property added successfully.');
        resetForm();
        fetchProperties();
      }
    }
    setSaving(false);
  }

  async function handleDelete(id: string) {
    if (writeDisabled) return;
    if (!confirm('Are you sure you want to delete this property? This cannot be undone.')) return;
    const { error } = await supabase.from('properties').delete().eq('id', id);
    if (error) {
      alert('Error deleting property. Please try again.');
    } else {
      if (editingId === id) resetForm();
      fetchProperties();
    }
  }

  const update = (field: keyof typeof form, value: string) => setForm((f) => ({ ...f, [field]: value }));

  return (
    <div className="admin-page">
      <section className="page-hero">
        <div className="hero-overlay" />
        <div className="page-hero-content reveal-up">
          <p className="eyebrow">Property Management</p>
          <h1>Manage<br /><em>Properties.</em></h1>
          <p className="hero-copy">Add, edit, and remove property listings. Upload photos and videos for each residence.</p>
        </div>
      </section>

      {sessionLoading ? (
        <section className="section admin-section"><p className="admin-loading"><Loader2 size={20} className="spin" /> Checking sign-in...</p></section>
      ) : !session ? (
        <section className="section admin-section"><AdminSignIn /></section>
      ) : (
      <section className="section admin-section">
        <div className="admin-session-bar">
          <span>Signed in as {session.user.email}</span>
          <button type="button" className="text-link" onClick={() => supabase.auth.signOut()}><LogOut size={14} /> Sign out</button>
        </div>
        {writeDisabled && (
          <div className="admin-alert admin-alert--error admin-security-alert">
            <Lock size={18} />
            <div>
              <strong>Property management is disabled.</strong>
              <p>Writes stay switched off until the database permissions are approved and tested. Listings can still be viewed on the Properties page.</p>
              <p className="admin-security-note">Sign-in is required to open this panel. Database rules are the final check on who can change listings.</p>
            </div>
          </div>
        )}
        <div className="admin-form-wrap" aria-disabled={writeDisabled}>
          <div className="form-title">
            <span>{editingId ? '02' : '01'}</span>
            <h3>{editingId ? 'Edit Property' : 'Add New Property'}</h3>
          </div>

          {savedMsg && <div className="admin-alert"><Check size={16} /> {savedMsg}</div>}

          <form className="enquiry-form admin-form" onSubmit={handleSubmit}>
            <div className="form-row">
              <label>Property Name<input required value={form.name} onChange={(e) => update('name', e.target.value)} placeholder="e.g. World One" disabled={writeDisabled} /></label>
              <label>Location<input required value={form.location} onChange={(e) => update('location', e.target.value)} placeholder="e.g. Lower Parel" disabled={writeDisabled} /></label>
            </div>

            <div className="form-row">
              <label>Status<select value={form.status} onChange={(e) => update('status', e.target.value)} disabled={writeDisabled}>
                <option>Featured</option><option>Exclusive</option><option>New</option><option>Private Listing</option>
              </select></label>
              <label>Price<input value={form.price} onChange={(e) => update('price', e.target.value)} placeholder="₹ 8.25 Cr onwards" disabled={writeDisabled} /></label>
            </div>

            <div className="form-row">
              <label>Configuration<input value={form.config} onChange={(e) => update('config', e.target.value)} placeholder="3 & 4 BHK · Furnished" disabled={writeDisabled} /></label>
              <label>BHK (for filtering)<input value={form.bhk} onChange={(e) => update('bhk', e.target.value)} placeholder="3 & 4 BHK" disabled={writeDisabled} /></label>
            </div>

            <div className="form-row">
              <label>Furnishing<select value={form.furnishing} onChange={(e) => update('furnishing', e.target.value)} disabled={writeDisabled}>
                <option>Fully Furnished</option><option>Semi-Furnished</option><option>Unfurnished</option>
              </select></label>
              <label>Carpet Area<input value={form.carpet_area} onChange={(e) => update('carpet_area', e.target.value)} placeholder="1,800–2,400 sq ft" disabled={writeDisabled} /></label>
            </div>

            <div className="form-row">
              <label>Parking<input value={form.parking} onChange={(e) => update('parking', e.target.value)} placeholder="2 Covered" disabled={writeDisabled} /></label>
              <label>Short Description<input value={form.description} onChange={(e) => update('description', e.target.value)} placeholder="Iconic tower residence · Two car parks" disabled={writeDisabled} /></label>
            </div>

            <div className="form-row">
              <label>Transaction Type (for Buy/Rent/Sell filter)<select value={form.transaction_type || ''} onChange={(e) => update('transaction_type', e.target.value)} disabled={writeDisabled}>
                <option value="">Select type</option><option value="Buy">Buy</option><option value="Rent">Rent</option><option value="Sell">Sell</option>
              </select></label>
              <label />
            </div>

            <div className="admin-upload-group">
              <label className="admin-upload-label">
                <span className="admin-upload-title"><ImageIcon size={15} /> Main Photo</span>
                <input type="file" accept="image/*" onChange={handleHeroUpload} disabled={writeDisabled} />
                <span className="admin-upload-btn">
                  {heroUpload === 'uploading' ? <Loader2 size={15} className="spin" /> : <Upload size={15} />}
                  {heroUpload === 'uploading' ? 'Uploading...' : heroUpload === 'done' ? 'Uploaded' : heroUpload === 'error' ? 'Failed — retry' : 'Choose photo'}
                </span>
              </label>
              {form.image_url && <img src={form.image_url} alt="Main property" className="admin-preview-single" />}
            </div>

            <div className="admin-upload-group">
              <label className="admin-upload-label">
                <span className="admin-upload-title"><ImageIcon size={15} /> Gallery Photos (multiple)</span>
                <input type="file" accept="image/*" multiple onChange={handleGalleryUpload} disabled={writeDisabled} />
                <span className="admin-upload-btn">
                  {galleryUploads === 'uploading' ? <Loader2 size={15} className="spin" /> : <Upload size={15} />}
                  {galleryUploads === 'uploading' ? 'Uploading...' : galleryUploads === 'done' ? 'Uploaded' : galleryUploads === 'error' ? 'Failed — retry' : 'Choose photos'}
                </span>
              </label>
              {form.gallery_urls.length > 0 && (
                <div className="admin-gallery-grid">
                  {form.gallery_urls.map((url, idx) => (
                    <div className="admin-gallery-item" key={idx}>
                      <img src={url} alt={`Gallery ${idx + 1}`} />
                      <button type="button" onClick={() => removeGalleryImage(idx)} aria-label="Remove photo"><X size={13} /></button>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div className="admin-upload-group">
              <label className="admin-upload-label">
                <span className="admin-upload-title"><Video size={15} /> Property Video (upload)</span>
                <input type="file" accept="video/*" onChange={handleVideoUpload} disabled={writeDisabled} />
                <span className="admin-upload-btn">
                  {videoUpload === 'uploading' ? <Loader2 size={15} className="spin" /> : <Upload size={15} />}
                  {videoUpload === 'uploading' ? 'Uploading...' : videoUpload === 'done' ? 'Uploaded' : videoUpload === 'error' ? 'Failed — retry' : 'Choose video'}
                </span>
              </label>
              {form.video_url && <video src={form.video_url} controls className="admin-preview-video" />}
            </div>

            <div className="admin-drive-links">
              <p className="admin-drive-hint">Or paste Google Drive links instead of uploading:</p>
              <label className="admin-drive-field">
                <span><FolderOpen size={14} /> Google Drive photo folder link</span>
                <input value={form.photo_folder_url} onChange={(e) => update('photo_folder_url', e.target.value)} placeholder="https://drive.google.com/drive/folders/..." disabled={writeDisabled} />
              </label>
              <label className="admin-drive-field">
                <span><LinkIcon size={14} /> Google Drive or YouTube video link</span>
                <input value={form.video_link_url} onChange={(e) => update('video_link_url', e.target.value)} placeholder="https://drive.google.com/file/d/... or https://youtube.com/watch?v=..." disabled={writeDisabled} />
              </label>
            </div>

            <div className="admin-form-actions">
              <button className="button button-dark" type="submit" disabled={writeDisabled || saving}>
                {saving ? 'Saving...' : editingId ? 'Update Property' : 'Add Property'} <ArrowRight size={16} />
              </button>
              {editingId && <button type="button" className="text-link" onClick={resetForm}>Cancel edit</button>}
            </div>
          </form>
        </div>

        <div className="admin-list-wrap">
          <div className="form-title">
            <span>03</span>
            <h3>Current Listings ({properties.length})</h3>
          </div>

          {loading ? (
            <p className="admin-loading"><Loader2 size={20} className="spin" /> Loading properties...</p>
          ) : properties.length === 0 ? (
            <p className="no-results">No properties yet. {writeDisabled ? 'Connect the database to start adding listings.' : 'Add your first listing above.'}</p>
          ) : (
            <div className="admin-list">
              {properties.map((prop) => (
                <div className="admin-list-item" key={prop.id}>
                  {prop.image_url ? (
                    <img src={prop.image_url} alt={prop.name} className="admin-list-thumb" />
                  ) : (
                    <div className="admin-list-thumb admin-list-thumb--empty"><ImageIcon size={20} /></div>
                  )}
                  <div className="admin-list-info">
                    <h4>{prop.name}</h4>
                    <p>{[prop.location, prop.config].filter(Boolean).join(' · ')}</p>
                    {prop.price && <span>{prop.price}</span>}
                    {prop.transaction_type && <small>Type: {prop.transaction_type}</small>}
                    {prop.gallery_urls && prop.gallery_urls.length > 0 && <small>{prop.gallery_urls.length} gallery photos</small>}
                    {prop.video_url && <small>Video uploaded</small>}
                    {prop.photo_folder_url && <small>Drive photo folder</small>}
                    {prop.video_link_url && <small>Drive/YouTube video link</small>}
                  </div>
                  <div className="admin-list-actions">
                    <button onClick={() => startEdit(prop)} disabled={writeDisabled}>Edit</button>
                    <button onClick={() => handleDelete(prop.id)} aria-label="Delete property" disabled={writeDisabled}><Trash2 size={16} /></button>
                  </div>
                </div>
              ))}
            </div>
          )}

          <Link className="text-link" to="/properties" style={{ marginTop: '24px' }}>View properties page <ArrowRight size={16} /></Link>
        </div>
      </section>
      )}
    </div>
  );
}

export default Admin;
