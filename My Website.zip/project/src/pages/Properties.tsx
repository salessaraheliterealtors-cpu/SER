import { useEffect, useState } from 'react';
import { ArrowRight, Loader2, X } from 'lucide-react';
import { Link, useSearchParams } from 'react-router-dom';
import { images } from '@/data';
import { parsePriceValue, budgetFilterCr, TRANSACTION_TYPES } from '@/lib/property';
import { useDocumentMeta } from '@/hooks/useDocumentMeta';
import { fetchAllProperties, type PropertyDetail } from '@/lib/property-detail';
import PropertyCard from '@/components/PropertyCard';

function Properties() {
  const [allProperties, setAllProperties] = useState<PropertyDetail[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadFailed, setLoadFailed] = useState(false);
  const [searchParams, setSearchParams] = useSearchParams();

  useDocumentMeta({
    title: 'Properties',
    description: 'Browse curated luxury residential properties for sale and rent across Worli, Lower Parel, Prabhadevi and Mahalaxmi with Sarah Elite Realtors.',
    path: '/properties',
  });

  const filterType = searchParams.get('type') || 'All';
  const filterLocation = searchParams.get('location') || 'All';
  const filterBhk = searchParams.get('bhk') || 'All';
  const filterBudget = searchParams.get('budget') || 'All';

  useEffect(() => {
    let cancelled = false;
    async function fetchProperties() {
      setLoading(true);
      const { properties: props, loadFailed: failed } = await fetchAllProperties();
      if (cancelled) return;
      setAllProperties(props);
      setLoadFailed(failed);
      setLoading(false);
    }
    fetchProperties();
    return () => { cancelled = true; };
  }, []);

  function updateFilter(key: string, value: string) {
    const newParams = new URLSearchParams(searchParams);
    if (value === 'All' || value === '' || value === 'Select budget') {
      newParams.delete(key);
    } else {
      newParams.set(key, value);
    }
    setSearchParams(newParams);
  }

  const filtered = allProperties.filter((p) => {
    const typeMatch = filterType === 'All' || p.transactionType === filterType;
    const locMatch = filterLocation === 'All' || p.location === filterLocation;
    const bhkMatch = filterBhk === 'All' || (p.bhk && p.bhk.includes(filterBhk));

    let budgetMatch = true;
    if (filterBudget !== 'All') {
      const priceLakh = parsePriceValue(p.price);
      const range = budgetFilterCr(filterBudget);
      if (priceLakh !== null && range) {
        budgetMatch = priceLakh >= range.min && priceLakh < range.max;
      } else {
        budgetMatch = false;
      }
    }

    return typeMatch && locMatch && bhkMatch && budgetMatch;
  });

  const hasActiveFilters = filterType !== 'All' || filterLocation !== 'All' || filterBhk !== 'All' || filterBudget !== 'All';

  function clearFilters() {
    setSearchParams(new URLSearchParams());
  }

  return (
    <>
      <section className="page-hero">
        <img className="hero-image" src={images.skyline} alt="Mumbai luxury skyline" />
        <div className="hero-overlay" />
        <div className="page-hero-content reveal-up">
          <p className="eyebrow">The Collection</p>
          <h1>The Address<br /><em>Matters.</em></h1>
          <p className="hero-copy">A curated collection of exceptional residences across Mumbai's most sought-after neighbourhoods.</p>
        </div>
      </section>

      <section className="section properties-section">
        <div className="filter-bar">
          <div className="filter-group">
            <span>I'm looking to</span>
            <div className="segmented-control segmented-control--filter" role="group" aria-label="Transaction type">
              {TRANSACTION_TYPES.map((type) => (
                <button
                  key={type}
                  type="button"
                  aria-pressed={filterType === type}
                  className={filterType === type ? 'active' : ''}
                  onClick={() => updateFilter('type', type)}
                >
                  {type}
                </button>
              ))}
            </div>
          </div>
          <div className="filter-group">
            <label htmlFor="filter-location" className="filter-label">Location</label>
            <select id="filter-location" value={filterLocation} onChange={(e) => updateFilter('location', e.target.value)}>
              <option value="All">All</option><option>Lower Parel</option><option>Worli</option><option>Prabhadevi</option><option>Mahalaxmi</option>
            </select>
          </div>
          <div className="filter-group">
            <label htmlFor="filter-bhk" className="filter-label">Configuration</label>
            <select id="filter-bhk" value={filterBhk} onChange={(e) => updateFilter('bhk', e.target.value)}>
              <option value="All">All</option><option>2 BHK</option><option>3 BHK</option><option>4 BHK</option><option>5+ BHK</option>
            </select>
          </div>
          <div className="filter-group">
            <label htmlFor="filter-budget" className="filter-label">Budget</label>
            <select id="filter-budget" value={filterBudget} onChange={(e) => updateFilter('budget', e.target.value)}>
              <option value="All">All</option><option>₹ 2–5 Cr</option><option>₹ 5–10 Cr</option><option>₹ 10 Cr+</option>
            </select>
          </div>
          <span className="filter-count">{filtered.length} residences</span>
          {hasActiveFilters && <button className="filter-clear" onClick={clearFilters}>Clear filters <X size={13} /></button>}
        </div>

        {loading ? (
          <p className="admin-loading"><Loader2 size={20} className="spin" /> Loading properties...</p>
        ) : loadFailed ? (
          <p className="no-results">We could not load our live listings right now. Please refresh the page, or contact us directly and we will share current availability.</p>
        ) : (
          <div className="property-grid">
            {filtered.map((property) => (
              <PropertyCard key={property.id} property={property} />
            ))}
          </div>
        )}

        {!loading && !loadFailed && filtered.length === 0 && <p className="no-results">No residences match your current filters. Try broadening your search.</p>}
      </section>

      <section className="owner-section section-dark">
        <div><p className="eyebrow">For owners</p><h2>Thinking of selling<br />or leasing your <em>property?</em></h2><p>Position your property with a boutique advisory approach designed to attract serious, qualified buyers and tenants.</p></div>
        <div className="owner-actions"><Link className="button button-gold" to="/contact">List your property <ArrowRight size={16} /></Link><Link className="text-link text-link-light" to="/contact">Speak to an advisor <ArrowRight size={16} /></Link></div>
      </section>
    </>
  );
}

export default Properties;
