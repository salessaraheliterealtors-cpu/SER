import { ArrowDownRight, ArrowRight, Check } from 'lucide-react';
import { Link } from 'react-router-dom';
import { images } from '@/data';
import { useDocumentMeta } from '@/hooks/useDocumentMeta';

function About() {
  useDocumentMeta({
    title: 'About',
    description: 'Sarah Elite Realtors is a boutique Mumbai luxury residential real-estate consultancy founded by Sajid Khan, offering personal advisory across South Mumbai.',
    path: '/about',
  });
  return (
    <>
      <section className="page-hero">
        <img className="hero-image" src={images.architecture} alt="Mumbai architectural detail" />
        <div className="hero-overlay" />
        <div className="page-hero-content reveal-up">
          <p className="eyebrow">About Sarah Elite</p>
          <h1>Local knowledge.<br /><em>Personal trust.</em></h1>
          <p className="hero-copy">A boutique, relationship-driven luxury residential real-estate consultancy founded by Sajid Khan.</p>
        </div>
      </section>

      <section className="statement-section">
        <div className="statement-image"><img src={images.interior} alt="Warm contemporary luxury living room" loading="lazy" /><span>01 / 03</span></div>
        <div className="statement-copy">
          <p className="eyebrow eyebrow-dark">The Sarah Elite difference</p>
          <h2>Not a volume<br /><em>brokerage.</em></h2>
          <h3>A personal advisory relationship.</h3>
          <p>Sarah Elite Realtors brings deep first-hand experience across Mumbai's luxury residential market. Every client engagement is handled personally, from the first conversation and property selection through site visits, negotiations and documentation.</p>
          <ul>
            <li><Check size={15} /> No call centres.</li>
            <li><Check size={15} /> No pressure selling.</li>
            <li><Check size={15} /> No unnecessary intermediaries.</li>
          </ul>
          <p className="serif-note">Just informed advice and personal attention.</p>
        </div>
      </section>

      <section className="founder-section">
        <div className="founder-portrait">
          <img src={images.bedroom} alt="Portrait-style detail of a luxury residence" loading="lazy" />
          <div className="portrait-label"><span>SAJID KHAN</span><small>FOUNDER & LUXURY RESIDENTIAL ADVISOR</small></div>
        </div>
        <div className="founder-copy">
          <p className="eyebrow eyebrow-dark">The person behind the perspective</p>
          <h2>Local knowledge.<br /><em>Personal trust.</em></h2>
          <p>Sajid has helped discerning clients navigate Mumbai's most nuanced residential market. His approach is deliberately personal — built on honest conversations, precise knowledge and lasting relationships.</p>
          <div className="founder-facts">
            <span><strong>4</strong>South Mumbai micro-markets</span>
            <span><strong>1:1</strong>Personal advisory</span>
          </div>
          <Link className="text-link" to="/contact">Start a conversation <ArrowRight size={16} /></Link>
        </div>
      </section>

      <section className="process-section">
        <div className="process-intro">
          <p className="eyebrow eyebrow-dark">A better way to move</p>
          <h2>From brief<br />to <em>keys.</em></h2>
          <p>Personally managed, from first conversation to the moment you walk through your new front door.</p>
        </div>
        <div className="process-list">
          {[['01', 'Understand', 'We understand your requirements, lifestyle and objectives.'], ['02', 'Curate', 'We shortlist properties that genuinely fit your brief.'], ['03', 'Experience', 'Private viewings and detailed property evaluation.'], ['04', 'Close', 'Negotiation, documentation and transaction support.']].map(([number, title, text]) => (
            <div className="process-step" key={number}>
              <span>{number}</span><div><h3>{title}</h3><p>{text}</p></div><ArrowDownRight size={18} />
            </div>
          ))}
        </div>
      </section>
    </>
  );
}

export default About;
