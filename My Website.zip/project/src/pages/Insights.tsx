import { useState } from 'react';
import { ArrowRight } from 'lucide-react';
import { images, insights } from '@/data';
import { useDocumentMeta } from '@/hooks/useDocumentMeta';

const ALL_CATEGORIES = ['All', 'Mumbai Real Estate', 'Market Insights', 'Neighbourhood Guides', 'Luxury Homes', 'Investment', 'Buying Guide', 'Selling Guide'];

function Insights() {
  const [activeCategory, setActiveCategory] = useState('All');

  useDocumentMeta({
    title: 'Insights',
    description: 'Insights, guides and neighbourhood stories from Mumbai luxury residential real estate market by Sarah Elite Realtors.',
    path: '/insights',
  });

  const filtered = activeCategory === 'All' ? insights : insights.filter((i) => i.category === activeCategory);

  return (
    <>
      <section className="page-hero">
        <img className="hero-image" src={images.city} alt="Mumbai cityscape" />
        <div className="hero-overlay" />
        <div className="page-hero-content reveal-up">
          <p className="eyebrow">The Journal</p>
          <h1>Perspectives<br /><em>on place.</em></h1>
          <p className="hero-copy">Insights, guides and neighbourhood stories from Mumbai's luxury residential market.</p>
        </div>
      </section>

      <section className="section insights-section">
        <div className="insights-categories">
          {ALL_CATEGORIES.map((cat) => (
            <button
              key={cat}
              className={`insight-category-chip ${activeCategory === cat ? 'active' : ''}`}
              onClick={() => setActiveCategory(cat)}
              aria-pressed={activeCategory === cat}
            >
              {cat}
            </button>
          ))}
        </div>
        <div className="insights-grid insights-grid--full">
          {filtered.map((insight) => (
            <article className="insight-card" key={insight.title}>
              <div className="insight-image">
                <img src={insight.image} alt={`${insight.title} — article illustration`} loading="lazy" />
                <span><ArrowRight size={17} /></span>
              </div>
              <p>{insight.category} <i>·</i> {insight.time}</p>
              <h3>{insight.title}</h3>
              <p className="insight-excerpt">{insight.excerpt}</p>
              <span className="text-link insight-coming-soon">Article coming soon <ArrowRight size={15} /></span>
            </article>
          ))}
        </div>
        {filtered.length === 0 && <p className="no-results">No articles in this category yet.</p>}
      </section>
    </>
  );
}

export default Insights;
