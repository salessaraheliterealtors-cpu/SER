import { useEffect, useState } from 'react';
import { ArrowDownRight, ArrowRight, Search } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { images, insights, locations } from '@/data';
import { fetchAllProperties, type PropertyDetail } from '@/lib/property-detail';
import { useDocumentMeta } from '@/hooks/useDocumentMeta';
import { TRANSACTION_TYPES } from '@/lib/property';
import PropertyCard from '@/components/PropertyCard';

function Home() {
  const [activeType, setActiveType] = useState<'Buy' | 'Rent' | 'Sell'>('Buy');
  const [featured, setFeatured] = useState<PropertyDetail[]>([]);
  const [featuredLoadFailed, setFeaturedLoadFailed] = useState(false);
  useDocumentMeta({
    title: 'Sarah Elite Realtors',
    description: 'Boutique Mumbai luxury residential real-estate consultancy specialising in exceptional homes across Worli, Lower Parel, Prabhadevi and Mahalaxmi.',
    path: '/',
  });
  const [location, setLocation] = useState('Any location');
  const [configuration, setConfiguration] = useState('Any configuration');
  const [budget, setBudget] = useState('Select budget');
  const navigate = useNavigate();

  useEffect(() => {
    let cancelled = false;
    fetchAllProperties().then(({ properties, loadFailed }) => {
      if (!cancelled) {
        setFeatured(properties);
        setFeaturedLoadFailed(loadFailed);
      }
    });
    return () => {
      cancelled = true;
    };
  }, []);

  function handleSearch() {
    const params = new URLSearchParams();
    params.set('type', activeType);
    if (location !== 'Any location') params.set('location', location);
    if (configuration !== 'Any configuration') params.set('bhk', configuration);
    if (budget !== 'Select budget') params.set('budget', budget);
    navigate(`/properties?${params.toString()}`);
  }

  return (
    <>
      <section className="hero" id="top">
        <img className="hero-image" src={images.hero} alt="Mumbai skyline at twilight" />
        <div className="hero-overlay" />
        <div className="hero-content reveal-up">
          <p className="eyebrow">Private residential advisory · South Mumbai</p>
          <h1>Exceptional Homes.<br /><em>Exceptional Mumbai.</em></h1>
          <p className="hero-copy">Luxury residential sales and leasing across Lower Parel, Worli, Prabhadevi and Mahalaxmi.</p>
          <div className="hero-actions">
            <Link className="button button-gold" to="/properties">Explore Properties <ArrowRight size={16} /></Link>
            <Link className="text-link text-link-light" to="/contact">Schedule a private consultation <ArrowDownRight size={16} /></Link>
          </div>
        </div>
        <div className="hero-rail"><span>18°58'N 72°49'E</span></div>
        <div className="scroll-cue"><span>Scroll to explore</span><span className="scroll-line" /></div>
        <div className="search-panel">
          <div className="search-type"><span>I'm looking to</span><div className="segmented-control" role="group" aria-label="Transaction type">{TRANSACTION_TYPES.map((type) => <button type="button" aria-pressed={activeType === type} className={activeType === type ? 'active' : ''} key={type} onClick={() => setActiveType(type)}>{type}</button>)}</div></div>
          <label><span>Location</span><select value={location} onChange={(e) => setLocation(e.target.value)}><option>Any location</option><option>Lower Parel</option><option>Worli</option><option>Prabhadevi</option><option>Mahalaxmi</option></select></label>
          <label><span>Property</span><select value={configuration} onChange={(e) => setConfiguration(e.target.value)}><option>Any configuration</option><option>2 BHK</option><option>3 BHK</option><option>4 BHK</option><option>5+ BHK</option></select></label>
          <label className="budget-label"><span>Budget</span><select value={budget} onChange={(e) => setBudget(e.target.value)}><option>Select budget</option><option>₹ 2–5 Cr</option><option>₹ 5–10 Cr</option><option>₹ 10 Cr+</option></select></label>
          <button className="search-submit" type="button" onClick={handleSearch}><Search size={17} /><span>Find my property</span></button>
        </div>
      </section>

      <section className="trust-bar section-dark">
        <div className="trust-stat"><strong>4</strong><p>Prime South Mumbai<br />micro-markets</p></div>
        <div className="trust-stat"><strong>1<span>:1</span></strong><p>Personal client<br />advisory</p></div>
      </section>

      <section className="section properties-section">
        <div className="section-heading split-heading">
          <div><p className="eyebrow eyebrow-dark">The collection · 01—06</p><h2>The Address<br /><em>Matters.</em></h2></div>
          <div className="heading-aside"><p>A curated collection of exceptional residences across Mumbai's most sought-after neighbourhoods.</p><Link className="text-link" to="/properties">View all properties <ArrowRight size={16} /></Link></div>
        </div>
        {featuredLoadFailed && <p className="no-results">We could not load our live listings right now. Please refresh the page, or contact us directly and we will share current availability.</p>}
        <div className="property-grid">
          {featured.slice(0, 4).map((property) => (
            <PropertyCard key={property.id} property={property} />
          ))}
        </div>
        <div className="collection-footer">{featured.length > 0 && <span>Showing 01—{String(Math.min(featured.length, 4)).padStart(2, '0')} of {String(featured.length).padStart(2, '0')}</span>}<Link className="text-link" to="/properties">View all properties <ArrowRight size={16} /></Link></div>
      </section>

      <section className="statement-section">
        <div className="statement-image"><img src={images.interior} alt="Warm contemporary luxury living room" loading="lazy" /><span>01 / 03</span></div>
        <div className="statement-copy">
          <p className="eyebrow eyebrow-dark">The Sarah Elite difference</p>
          <h2>Not a volume<br /><em>brokerage.</em></h2>
          <h3>A personal advisory relationship.</h3>
          <p>Sarah Elite Realtors brings deep first-hand experience across Mumbai's luxury residential market. Every client engagement is handled personally, from the first conversation and property selection through site visits, negotiations and documentation.</p>
          <Link className="button button-dark" to="/about">Meet Sajid Khan <ArrowRight size={16} /></Link>
        </div>
      </section>

      <section className="section locations-section">
        <div className="section-heading centered-heading"><p className="eyebrow eyebrow-dark">Know the neighbourhood</p><h2>Four Addresses.<br /><em>Four Mumbai stories.</em></h2></div>
        <div className="locations-grid">
          {locations.map((place) => (
            <article className="location-panel" key={place.name}>
              <img src={place.image} alt={`${place.name} Mumbai neighbourhood`} loading="lazy" />
              <div className="location-overlay" />
              <div className="location-content">
                <span className="location-number">{place.number}</span><h3>{place.name}</h3>
                <p className="location-line">{place.line}</p>
                <Link to="/properties">Explore {place.name} <ArrowRight size={16} /></Link>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className="owner-section section-dark">
        <div><p className="eyebrow">For owners</p><h2>Thinking of selling<br />or leasing your <em>property?</em></h2><p>Position your property with a boutique advisory approach designed to attract serious, qualified buyers and tenants.</p></div>
        <div className="owner-actions"><Link className="button button-gold" to="/contact">List your property <ArrowRight size={16} /></Link><Link className="text-link text-link-light" to="/contact">Speak to an advisor <ArrowRight size={16} /></Link></div>
      </section>

      <section className="section insights-section">
        <div className="section-heading split-heading">
          <div><p className="eyebrow eyebrow-dark">The journal</p><h2>Perspectives<br /><em>on place.</em></h2></div>
          <Link className="text-link" to="/insights">Explore all insights <ArrowRight size={16} /></Link>
        </div>
        <div className="insights-grid">
          {insights.slice(0, 3).map((insight) => (
            <article className="insight-card" key={insight.title}>
              <Link className="insight-image" to="/insights"><img src={insight.image} alt="" loading="lazy" /><span><ArrowRight size={17} /></span></Link>
              <p>{insight.category}</p><h3>{insight.title}</h3><Link className="text-link" to="/insights">Read article <ArrowRight size={15} /></Link>
            </article>
          ))}
        </div>
      </section>
    </>
  );
}

export default Home;
