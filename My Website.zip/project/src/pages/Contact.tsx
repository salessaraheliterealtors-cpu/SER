import { useState, type ChangeEvent, type FormEvent } from 'react';
import { ArrowRight, Check, Compass, Loader2, Mail, Phone } from 'lucide-react';
import { contactInfo, socialLinks } from '@/data';
import { WhatsAppIcon } from '@/components/WhatsAppIcon';
import { useDocumentMeta } from '@/hooks/useDocumentMeta';

type SubmitStatus = 'idle' | 'submitting' | 'success' | 'error';

type FormState = {
  name: string;
  phone: string;
  email: string;
  interest: string;
  message: string;
  company: string;
};

const initialForm: FormState = { name: '', phone: '', email: '', interest: 'Buying a residence', message: '', company: '' };

const CONTACT_ENDPOINT = import.meta.env.VITE_CONTACT_ENDPOINT || '';

function Contact() {
  const [form, setForm] = useState<FormState>(initialForm);
  const [status, setStatus] = useState<SubmitStatus>('idle');
  const [errorMsg, setErrorMsg] = useState('');

  useDocumentMeta({
    title: 'Contact',
    description: 'Start a discreet, one-to-one conversation with Sarah Elite Realtors about buying, leasing, selling or investing in a luxury Mumbai residence.',
    path: '/contact',
  });

  function update<K extends keyof FormState>(key: K, value: FormState[K]) {
    setForm((f) => ({ ...f, [key]: value }));
    if (status === 'error') setStatus('idle');
  }

  function validate(): string | null {
    if (!form.name.trim()) return 'Please enter your name.';
    if (!form.phone.trim()) return 'Please enter your phone number.';
    if (!/^[+\d][\d\s-]{6,}$/.test(form.phone.trim())) return 'Please enter a valid phone number.';
    if (!form.email.trim()) return 'Please enter your email address.';
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email.trim())) return 'Please enter a valid email address.';
    if (form.message.trim().length > 2000) return 'Your message is too long. Please keep it under 2000 characters.';
    return null;
  }

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (status === 'submitting') return;
    const validationError = validate();
    if (validationError) {
      setStatus('error');
      setErrorMsg(validationError);
      return;
    }

    if (!CONTACT_ENDPOINT) {
      setStatus('error');
      setErrorMsg('The online enquiry form is not yet configured. Please reach us directly using the phone, WhatsApp or email details on this page.');
      return;
    }

    setStatus('submitting');
    setErrorMsg('');

    try {
      const response = await fetch(CONTACT_ENDPOINT, {
        method: 'POST',
        headers: { 'Content-Type': 'text/plain;charset=utf-8' },
        body: JSON.stringify(form),
      });
      const data = await response.json().catch(() => null);
      if (!response.ok || !data || data.ok !== true) {
        throw new Error(data?.error || `Request failed (${response.status})`);
      }
      setStatus('success');
      setForm(initialForm);
    } catch {
      setStatus('error');
      setErrorMsg('We could not send your enquiry right now. Please try again, or contact us directly by phone or WhatsApp.');
    }
  }

  return (
    <>
      <section className="page-hero">
        <img className="hero-image" src="https://images.pexels.com/photos/38279448/pexels-photo-38279448.jpeg?auto=compress&cs=tinysrgb&h=650&w=940" alt="Mumbai sea link at sunset" />
        <div className="hero-overlay" />
        <div className="page-hero-content reveal-up">
          <p className="eyebrow">Your next address begins here</p>
          <h1>Let's find<br /><em>your address.</em></h1>
          <p className="hero-copy">A discreet, one-to-one conversation about your requirement — whether you are buying, leasing, selling or investing.</p>
        </div>
      </section>

      <section className="contact-section">
        <div className="contact-intro">
          <h2>Let's find<br /><em>your address.</em></h2>
          <p>A discreet, one-to-one conversation about your requirement — whether you are buying, leasing, selling or investing.</p>
          <div className="contact-details">
            <a href={contactInfo.phoneHref}><Phone size={16} /> {contactInfo.phone}</a>
            <a href={socialLinks.whatsapp} aria-label="Chat with Sarah Elite Realtors on WhatsApp"><WhatsAppIcon size={16} /> Chat on WhatsApp</a>
            <a href={`mailto:${contactInfo.email}`}><Mail size={16} /> {contactInfo.email}</a>
            <span><Compass size={16} /> {contactInfo.location}</span>
          </div>
        </div>
        <form className="enquiry-form" onSubmit={handleSubmit} noValidate>
          {status === 'success' ? (
            <div className="form-success">
              <Check size={24} /><h3>Thank you.</h3>
              <p>Your enquiry has been received. Our advisory team will be in touch personally.</p>
              <button type="button" className="text-link" onClick={() => { setStatus('idle'); setForm(initialForm); }}>Send another enquiry <ArrowRight size={15} /></button>
            </div>
          ) : (
            <>
              <div className="form-title"><span>01</span><h3>Start a conversation</h3></div>
              <label htmlFor="contact-name">Your name<input id="contact-name" name="name" required value={form.name} onChange={(e) => update('name', e.target.value)} placeholder="Full name" autoComplete="name" /></label>
              <div className="form-row">
                <label htmlFor="contact-phone">Phone<input id="contact-phone" name="phone" type="tel" required value={form.phone} onChange={(e) => update('phone', e.target.value)} placeholder="+91" autoComplete="tel" /></label>
                <label htmlFor="contact-email">Email<input id="contact-email" name="email" type="email" required value={form.email} onChange={(e) => update('email', e.target.value)} placeholder="you@email.com" autoComplete="email" /></label>
              </div>
              <label htmlFor="contact-interest">I'm interested in<select id="contact-interest" name="interest" value={form.interest} onChange={(e) => update('interest', e.target.value)}><option>Buying a residence</option><option>Leasing a residence</option><option>Selling or leasing my property</option><option>Investment advisory</option></select></label>
              <label htmlFor="contact-message">Your message<textarea id="contact-message" name="message" value={form.message} onChange={(e) => update('message', e.target.value)} placeholder="Tell us a little about what you're looking for..." rows={3} maxLength={2000} /></label>

              <input type="text" name="company" value={form.company} onChange={(e: ChangeEvent<HTMLInputElement>) => update('company', e.target.value)} tabIndex={-1} autoComplete="off" aria-hidden="true" style={{ position: 'absolute', left: '-9999px', width: 1, height: 1, opacity: 0 }} />

              {status === 'error' && (
                <div className="form-error" role="alert">
                  {errorMsg}
                  {!CONTACT_ENDPOINT && (
                    <span className="form-error-contacts">
                      <a href={contactInfo.phoneHref}><Phone size={14} /> {contactInfo.phone}</a>
                      <a href={socialLinks.whatsapp} aria-label="Chat on WhatsApp"><WhatsAppIcon size={14} /> WhatsApp</a>
                      <a href={`mailto:${contactInfo.email}`}><Mail size={14} /> {contactInfo.email}</a>
                    </span>
                  )}
                </div>
              )}

              <button className="button button-dark" type="submit" disabled={status === 'submitting'}>
                {status === 'submitting' ? <><Loader2 size={16} className="spin" /> Sending...</> : <>Request a consultation <ArrowRight size={16} /></>}
              </button>
            </>
          )}
        </form>
      </section>
    </>
  );
}

export default Contact;
