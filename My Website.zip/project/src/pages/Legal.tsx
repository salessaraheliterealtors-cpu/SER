import type { ReactNode } from 'react';
import { useDocumentMeta } from '@/hooks/useDocumentMeta';

type LegalSection = { heading: string; body: ReactNode[] };

const LAST_UPDATED = <CONFIRM>Date of publication</CONFIRM>;

const BUSINESS_NAME = 'Sarah Elite Realtors';
const BUSINESS_ADDRESS = 'Lower Parel, Mumbai, Maharashtra – 400013';
const BUSINESS_PHONE = '+91 9082619659';
const BUSINESS_EMAIL = 'info@saraheliterealtors.com';

function CONFIRM({ children }: { children: ReactNode }) {
  return <mark className="legal-confirm">[{children}]</mark>;
}

function LegalPage({ eyebrow, title, intro, sections }: { eyebrow: string; title: ReactNode; intro: string; sections: LegalSection[] }) {
  return (
    <>
      <section className="page-hero">
        <div className="hero-overlay" />
        <div className="page-hero-content reveal-up">
          <p className="eyebrow">{eyebrow}</p>
          <h1>{title}</h1>
          <p className="hero-copy">{intro}</p>
        </div>
      </section>
      <section className="section legal-section">
        <article className="legal-article">
          <p className="legal-updated">Draft. Last updated: {LAST_UPDATED}</p>
          {sections.map((section) => (
            <div className="legal-block" key={section.heading}>
              <h2>{section.heading}</h2>
              {section.body.map((paragraph, idx) => (
                <p key={idx}>{paragraph}</p>
              ))}
            </div>
          ))}
        </article>
      </section>
    </>
  );
}

export function PrivacyPolicy() {
  useDocumentMeta({
    title: 'Privacy Policy',
    description: 'How Sarah Elite Realtors collects, uses and protects personal information shared through this website.',
    path: '/privacy',
  });

  return (
    <LegalPage
      eyebrow="Legal"
      title={<>Privacy<br /><em>policy.</em></>}
      intro="How we collect, use and protect the personal information you share with us."
      sections={[
        {
          heading: '1. Who we are',
          body: [
            `${BUSINESS_NAME} is a sole proprietorship owned by Sajid Khan, based at ${BUSINESS_ADDRESS}. You can contact us at ${BUSINESS_EMAIL} or ${BUSINESS_PHONE}.`,
          ],
        },
        {
          heading: '2. Information we collect',
          body: [
            'When you submit an enquiry, we collect your name, phone number, email address, the type of property you are interested in, and any message you choose to write. If you enquire about a specific listing, the property name and page address are included.',
            'Our hosting provider may keep standard technical logs, such as browser type and pages requested, as part of running the website.',
          ],
        },
        {
          heading: '3. How we use your information',
          body: [
            'We use your details to respond to your enquiry and arrange a consultation, and, where you ask, to send information about properties you are interested in.',
            <>Marketing use beyond this: <CONFIRM>Confirm whether enquiry details are ever used for newsletters or follow-up campaigns</CONFIRM></>,
          ],
        },
        {
          heading: '4. Where your enquiry is stored',
          body: [
            'Enquiries are emailed to our office and recorded in a private spreadsheet. Property listings are stored in a managed database hosted by Supabase.',
          ],
        },
        {
          heading: '5. Sharing your information',
          body: [
            <>Confirm and state here whether enquiry details are shared with anyone other than the proprietor and the service providers named in this policy: <CONFIRM>Sharing practice to be confirmed</CONFIRM></>,
          ],
        },
        {
          heading: '6. Third-party services',
          body: [
            'The website uses Vercel for hosting, Google services (Apps Script and Drive, and YouTube embeds where a video link is provided), and Supabase for listing data. These providers process data under their own privacy policies. WhatsApp links open a conversation under WhatsApp\'s own terms.',
          ],
        },
        {
          heading: '7. Cookies',
          body: [
            <>Confirm whether the website sets cookies or uses analytics: <CONFIRM>Cookie and analytics details to be confirmed</CONFIRM></>,
          ],
        },
        {
          heading: '8. How long we keep information',
          body: [
            <>Enquiry records are kept for <CONFIRM>retention period</CONFIRM> and then deleted.</>,
          ],
        },
        {
          heading: '9. Your rights',
          body: [
            <>You may ask to see, correct or delete the personal information we hold about you by writing to {BUSINESS_EMAIL}. We will respond within <CONFIRM>response timeframe</CONFIRM>.</>,
          ],
        },
        {
          heading: '10. Security',
          body: [
            'We take reasonable steps to protect your information, including limiting access to enquiry records and keeping secret keys off the public website. No internet transmission is completely secure, so absolute security cannot be guaranteed.',
          ],
        },
        {
          heading: '11. Changes to this policy',
          body: [
            'We may update this policy from time to time. The date at the top of this page shows when it last changed.',
          ],
        },
      ]}
    />
  );
}

export function TermsAndConditions() {
  useDocumentMeta({
    title: 'Terms & Conditions',
    description: 'Terms governing use of the Sarah Elite Realtors website and property listings.',
    path: '/terms',
  });

  return (
    <LegalPage
      eyebrow="Legal"
      title={<>Terms &amp;<br /><em>conditions.</em></>}
      intro="The terms that apply when you use this website and the listings published on it."
      sections={[
        {
          heading: '1. Who we are',
          body: [
            `${BUSINESS_NAME} is a sole proprietorship owned by Sajid Khan, providing real estate advisory, residential sales and leasing in South Mumbai from ${BUSINESS_ADDRESS}.`,
          ],
        },
        {
          heading: '2. Acceptance',
          body: [
            'By using this website you agree to these terms. If you do not agree, please do not use the site.',
          ],
        },
        {
          heading: '3. Use of the website',
          body: [
            'You may browse the site, view listings and send enquiries for lawful purposes. You must not disrupt the site, copy listing content in bulk, or submit false or abusive enquiries.',
          ],
        },
        {
          heading: '4. Listings and information',
          body: [
            <>Property details, prices, areas and images are provided for general information and may change without notice. Where a price is shown as "Price on Request" or "onwards", it is indicative only. <CONFIRM>Confirm listing and availability statement, and whether any listing is offered as an agent or on behalf of an owner</CONFIRM></>,
          ],
        },
        {
          heading: '5. Enquiries and consultations',
          body: [
            'Submitting an enquiry does not create a binding agreement to buy, sell, lease or invest. Any transaction is subject to a separate written agreement.',
          ],
        },
        {
          heading: '6. Intellectual property',
          body: [
            'The text, logos, photographs and design of this website belong to Sarah Elite Realtors or its licensors and may not be reused without written permission.',
          ],
        },
        {
          heading: '7. Third-party links',
          body: [
            'The site links to external services such as WhatsApp, Google Drive and YouTube. We are not responsible for their content or practices.',
          ],
        },
        {
          heading: '8. Limitation of liability',
          body: [
            'To the fullest extent permitted by law, we are not liable for losses arising from your use of the site or reliance on its content. Nothing in these terms limits liability that cannot be excluded by law.',
          ],
        },
        {
          heading: '9. Governing law and jurisdiction',
          body: [
            <>These terms are governed by the laws of India. Courts in <CONFIRM>jurisdiction, e.g. Mumbai</CONFIRM> have jurisdiction. Confirm before publishing.</>,
          ],
        },
        {
          heading: '10. Changes',
          body: [
            'We may update these terms at any time. Continued use of the site after changes means you accept the updated terms.',
          ],
        },
      ]}
    />
  );
}

export function Disclaimer() {
  useDocumentMeta({
    title: 'Disclaimer',
    description: 'Important information about the accuracy and purpose of content on the Sarah Elite Realtors website.',
    path: '/disclaimer',
  });

  return (
    <LegalPage
      eyebrow="Legal"
      title={<>Important<br /><em>disclaimer.</em></>}
      intro="Please read this before relying on any information published on this website."
      sections={[
        {
          heading: 'General information only',
          body: [
            'Content on this website is for general information and does not constitute legal, financial, tax or investment advice. Consult qualified professionals before making decisions.',
          ],
        },
        {
          heading: 'Accuracy of listings',
          body: [
            'We take care to keep listings accurate, but availability, specifications, areas, prices and images may change or contain errors. Confirm all details before any decision.',
          ],
        },
        {
          heading: 'Images and illustrations',
          body: [
            'Some photographs are illustrative only and may not show the final property or its current condition. Sample listings shown when the live database is unavailable are not real inventory.',
          ],
        },
        {
          heading: 'Regulatory registration',
          body: [
            <>No project or listing on this website is currently shown with a MahaRERA registration number. <CONFIRM>MahaRERA registration numbers for each listed project to be supplied and verified before any is displayed. Until verified, no RERA registration is claimed.</CONFIRM></>,
          ],
        },
        {
          heading: 'Market commentary',
          body: [
            'Articles and market commentary express general views and are not forecasts of future prices or returns.',
          ],
        },
        {
          heading: 'External links',
          body: [
            'We are not responsible for the content of third-party websites or services linked from this site.',
          ],
        },
      ]}
    />
  );
}
