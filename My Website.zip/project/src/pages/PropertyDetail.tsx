import { useCallback, useEffect, useMemo, useState, type ChangeEvent, type FormEvent } from 'react';
import { ArrowLeft, ArrowRight, BedDouble, Check, ChevronRight, Compass, Copy, FolderOpen, Home as HomeIcon, Loader2, Mail, Maximize, Phone, Play, ShieldCheck, X } from 'lucide-react';
import { Link, useParams } from 'react-router-dom';
import { contactInfo, socialLinks } from '@/data';
import { WhatsAppIcon } from '@/components/WhatsAppIcon';
import PropertyCard from '@/components/PropertyCard';
import { useDocumentMeta } from '@/hooks/useDocumentMeta';
import { fetchAllProperties, findPropertyBySlug, getDriveFolderEmbed, getVideoEmbed, type PropertyDetail } from '@/lib/property-detail';

type SubmitStatus = 'idle' | 'submitting' | 'success' | 'error';

type EnquiryForm = {
  name: string;
  phone: string;
  email: string;
  message: string;
  company: string;
};

const CONTACT_ENDPOINT = import.meta.env.VITE_CONTACT_ENDPOINT || '';

function PropertyDetailPage() {
  const { slug } = useParams<{ slug: string }>();
  const [property, setProperty] = useState<PropertyDetail | null>(null);
  const [allProperties, setAllProperties] = useState<PropertyDetail[]>([]);
  const [loading, setLoading] = useState(true);
  const [notFound, setNotFound] = useState(false);
  const [loadFailed, setLoadFailed] = useState(false);
  const [activeImage, setActiveImage] = useState('');
  const [lightboxOpen, setLightboxOpen] = useState(false);
  const [copied, setCopied] = useState(false);

  const [enquiry, setEnquiry] = useState<EnquiryForm>({ name: '', phone: '', email: '', message: '', company: '' });
  const [enquiryStatus, setEnquiryStatus] = useState<SubmitStatus>('idle');
  const [enquiryError, setEnquiryError] = useState('');

  useEffect(() => {
    let cancelled = false;
    async function load() {
      setLoading(true);
      setNotFound(false);
      setLoadFailed(false);
      const { properties: props, loadFailed: failed } = await fetchAllProperties();
      if (cancelled) return;
      setAllProperties(props);
      setLoadFailed(failed);
      const found = slug ? findPropertyBySlug(props, slug) : null;
      if (found) {
        setProperty(found);
        setActiveImage(found.image);
        setEnquiry((prev) => ({
          ...prev,
          message: `I'm interested in ${found.name} in ${found.location}${found.transactionType ? ` (${found.transactionType})` : ''}. Please share more details.`,
        }));
      } else {
        setNotFound(!failed);
      }
      setLoading(false);
    }
    load();
    return () => { cancelled = true; };
  }, [slug]);

  const propertyUrl = property ? `https://ser-brown.vercel.app/properties/${property.slug}` : '';

  useDocumentMeta({
    title: property ? `${property.name} — ${property.location}` : 'Property Not Found',
    description: property
      ? [`${property.name}, ${property.location}`, property.config, property.price, property.description].filter(Boolean).join('. ')
      : 'The property you were looking for is no longer available.',
    path: property ? `/properties/${property.slug}` : '/properties',
    image: property?.image || undefined,
    noindex: notFound,
  });

  const galleryImages = useMemo(() => property ? [property.image, ...property.galleryUrls].filter((u, i, arr) => u && arr.indexOf(u) === i) : [], [property]);
  const folderEmbed = property ? getDriveFolderEmbed(property.photoFolderUrl) : null;
  const videoEmbed = property ? getVideoEmbed(property.videoLinkUrl) : null;
  const related = useMemo(() => property ? allProperties.filter((p) => p.id !== property.id && p.location === property.location).slice(0, 3) : [], [property, allProperties]);

  const openLightbox = useCallback((url: string) => {
    setActiveImage(url);
    setLightboxOpen(true);
  }, []);

  const closeLightbox = useCallback(() => {
    setLightboxOpen(false);
  }, []);

  const nextLightbox = useCallback((e?: React.SyntheticEvent) => {
    e?.stopPropagation();
    setActiveImage((prev) => {
      const idx = galleryImages.indexOf(prev);
      if (idx === -1 || galleryImages.length === 0) return prev;
      return galleryImages[(idx + 1) % galleryImages.length];
    });
  }, [galleryImages]);

  const prevLightbox = useCallback((e?: React.SyntheticEvent) => {
    e?.stopPropagation();
    setActiveImage((prev) => {
      const idx = galleryImages.indexOf(prev);
      if (idx === -1 || galleryImages.length === 0) return prev;
      return galleryImages[(idx - 1 + galleryImages.length) % galleryImages.length];
    });
  }, [galleryImages]);

  useEffect(() => {
    if (!lightboxOpen) return;
    function onKey(e: KeyboardEvent) {
      if (e.key === 'Escape') closeLightbox();
      if (e.key === 'ArrowRight') nextLightbox();
      if (e.key === 'ArrowLeft') prevLightbox();
    }
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, [lightboxOpen, closeLightbox, nextLightbox, prevLightbox]);

  async function copyLink() {
    try {
      await navigator.clipboard.writeText(propertyUrl);
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    } catch {
      setCopied(false);
    }
  }

  function shareOnWhatsApp() {
    if (!property) return;
    const text = encodeURIComponent(`I'd like to share this property: ${property.name} — ${property.location}. ${propertyUrl}`);
    window.open(`${socialLinks.whatsapp}?text=${text}`, '_blank', 'noopener,noreferrer');
  }

  function updateEnquiry<K extends keyof EnquiryForm>(key: K, value: EnquiryForm[K]) {
    setEnquiry((f) => ({ ...f, [key]: value }));
    if (enquiryStatus === 'error') setEnquiryStatus('idle');
  }

  function validateEnquiry(): string | null {
    if (!enquiry.name.trim()) return 'Please enter your name.';
    if (!enquiry.phone.trim()) return 'Please enter your phone number.';
    if (!/^[+\d][\d\s-]{6,}$/.test(enquiry.phone.trim())) return 'Please enter a valid phone number.';
    if (!enquiry.email.trim()) return 'Please enter your email address.';
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(enquiry.email.trim())) return 'Please enter a valid email address.';
    if (enquiry.message.trim().length > 2000) return 'Your message is too long. Please keep it under 2000 characters.';
    return null;
  }

  async function handleEnquirySubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (enquiryStatus === 'submitting') return;
    const validationError = validateEnquiry();
    if (validationError) {
      setEnquiryStatus('error');
      setEnquiryError(validationError);
      return;
    }

    if (!CONTACT_ENDPOINT) {
      setEnquiryStatus('error');
      setEnquiryError('The online enquiry form is not yet configured. Please reach us directly using the phone, WhatsApp or email details below.');
      return;
    }

    setEnquiryStatus('submitting');
    setEnquiryError('');

    const payload = {
      ...enquiry,
      interest: `Property enquiry: ${property?.name || ''}`,
      property_name: property?.name || '',
      property_id: property?.id || '',
      property_url: propertyUrl,
    };

    try {
      const response = await fetch(CONTACT_ENDPOINT, {
        method: 'POST',
        headers: { 'Content-Type': 'text/plain;charset=utf-8' },
        body: JSON.stringify(payload),
      });
      const data = await response.json().catch(() => null);
      if (!response.ok || !data || data.ok !== true) {
        throw new Error(data?.error || `Request failed (${response.status})`);
      }
      setEnquiryStatus('success');
      setEnquiry({ name: '', phone: '', email: '', message: '', company: '' });
    } catch {
      setEnquiryStatus('error');
      setEnquiryError('We could not send your enquiry right now. Please try again, or contact us directly by phone or WhatsApp.');
    }
  }

  if (loading) {
    return (
      <div className="section" style={{ minHeight: '60vh', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <p className="admin-loading"><Loader2 size={24} className="spin" /> Loading property...</p>
      </div>
    );
  }

  if (loadFailed && !property) {
    return (
      <section className="section" style={{ minHeight: '60vh', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', textAlign: 'center' }}>
        <p className="eyebrow eyebrow-dark">Listings Unavailable</p>
        <h1 style={{ color: 'var(--ink)', fontSize: 'clamp(40px, 5vw, 64px)' }}>We cannot load<br /><em>this residence right now.</em></h1>
        <p style={{ color: 'var(--muted)', maxWidth: '380px', marginBottom: '32px' }}>Our live listings could not be loaded. Please try again shortly, or contact us directly and we will share the details.</p>
        <div style={{ display: 'flex', gap: '20px', flexWrap: 'wrap', justifyContent: 'center' }}>
          <Link className="button button-dark" to="/properties">Back to properties <ArrowRight size={16} /></Link>
          <Link className="text-link" to="/contact">Contact us <ArrowRight size={16} /></Link>
        </div>
      </section>
    );
  }

  if (notFound || !property) {
    return (
      <section className="section" style={{ minHeight: '60vh', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', textAlign: 'center' }}>
        <p className="eyebrow eyebrow-dark">Property Unavailable</p>
        <h1 style={{ color: 'var(--ink)', fontSize: 'clamp(40px, 5vw, 64px)' }}>This residence<br /><em>is no longer listed.</em></h1>
        <p style={{ color: 'var(--muted)', maxWidth: '380px', marginBottom: '32px' }}>The property you were looking for may have been sold, leased, or removed from our collection. Browse our current listings or contact us directly.</p>
        <div style={{ display: 'flex', gap: '20px', flexWrap: 'wrap', justifyContent: 'center' }}>
          <Link className="button button-dark" to="/properties">Browse all properties <ArrowRight size={16} /></Link>
          <Link className="text-link" to="/contact">Contact us <ArrowRight size={16} /></Link>
        </div>
      </section>
    );
  }

  const specs = property
    ? [
        { label: 'Configuration', value: property.bhk, Icon: BedDouble },
        { label: 'Furnishing', value: property.furnishing, Icon: ShieldCheck },
        { label: 'Carpet Area', value: property.carpetArea, Icon: Maximize },
        { label: 'Parking', value: property.parking, Icon: Compass },
      ].filter((spec) => spec.value)
    : [];

  const whatsappEnquiryText = encodeURIComponent(`I'm interested in ${property.name} — ${property.location}. Please share more details. ${propertyUrl}`);
  const whatsappEnquiryUrl = `${socialLinks.whatsapp}?text=${whatsappEnquiryText}`;

  return (
    <>
      {/* Breadcrumbs */}
      <nav className="breadcrumbs" aria-label="Breadcrumb">
        <Link to="/"><HomeIcon size={13} /> Home</Link>
        <ChevronRight size={13} />
        <Link to="/properties">Properties</Link>
        <ChevronRight size={13} />
        <span aria-current="page">{property.name}</span>
      </nav>

      {/* Hero */}
      <section className="detail-hero">
        {property.image ? (
          <img className="hero-image" src={property.image} alt={`${property.name} luxury residence in ${property.location}`} onError={(e) => { e.currentTarget.style.display = 'none'; }} />
        ) : (
          <div className="hero-image hero-image--placeholder" aria-hidden="true" />
        )}
        <div className="hero-overlay" />
        <div className="detail-hero-content">
          <p className="eyebrow">{[property.status, property.location, property.transactionType].filter(Boolean).join(' · ')}</p>
          <h1>{property.name}</h1>
          {property.config && <p className="hero-copy">{property.config}</p>}
          {property.price && <div className="detail-hero-price">{property.price}</div>}
          <div className="detail-hero-actions">
            <a className="button button-gold" href={whatsappEnquiryUrl} target="_blank" rel="noopener noreferrer" aria-label="Enquire about this property on WhatsApp">
              <WhatsAppIcon size={16} /> Enquire Now
            </a>
            <a className="button button-dark" href={contactInfo.phoneHref}><Phone size={15} /> Call Advisor</a>
          </div>
        </div>
      </section>

      {/* Main content + enquiry sidebar */}
      <section className="detail-section">
        <div className="detail-main">
          {property.description && (
            <div className="detail-description">
              <p className="eyebrow eyebrow-dark">The Residence</p>
              <h2>{property.name}<br /><em>{property.location}</em></h2>
              <p className="detail-copy">{property.description}</p>
            </div>
          )}

          {specs.length > 0 && (
            <div className="detail-specs">
              {specs.map(({ label, value, Icon }) => (
                <div className="detail-spec" key={label}><Icon size={18} /><div><span>{label}</span><strong>{value}</strong></div></div>
              ))}
            </div>
          )}

          {/* Gallery */}
          {galleryImages.length > 0 && (
            <div className="detail-gallery-section">
              <p className="eyebrow eyebrow-dark">Gallery</p>
              <div className="detail-gallery">
                {galleryImages.map((url, idx) => (
                  <button
                    key={idx}
                    type="button"
                    className="detail-gallery-item"
                    onClick={() => openLightbox(url)}
                    aria-label={`View ${property.name} photo ${idx + 1} full size`}
                  >
                    <img src={url} alt={`${property.name} photo ${idx + 1}`} loading={idx === 0 ? undefined : 'lazy'} onError={(e) => { e.currentTarget.style.display = 'none'; }} />
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Drive folder embed */}
          {folderEmbed && (
            <div className="detail-drive-section">
              <p className="detail-drive-label"><FolderOpen size={15} /> Property Photos</p>
              <iframe src={folderEmbed} className="detail-drive-iframe" allowFullScreen title={`${property.name} photo gallery`} />
            </div>
          )}

          {/* Video embed */}
          {videoEmbed && (
            <div className="detail-drive-section">
              <p className="detail-drive-label"><Play size={15} /> Property Video</p>
              <iframe src={videoEmbed} className="detail-drive-iframe detail-drive-iframe--video" allowFullScreen title={`${property.name} video tour`} />
            </div>
          )}

          {property.videoUrl && (
            <video src={property.videoUrl} controls className="detail-video" />
          )}

          {/* Share bar */}
          <div className="detail-share">
            <span className="detail-share-label">Share this property</span>
            <button type="button" className="detail-share-btn" onClick={shareOnWhatsApp} aria-label="Share this property on WhatsApp">
              <WhatsAppIcon size={16} /> WhatsApp
            </button>
            <button type="button" className="detail-share-btn" onClick={copyLink} aria-label="Copy property link to clipboard">
              {copied ? <><Check size={16} /> Copied</> : <><Copy size={16} /> Copy Link</>}
            </button>
          </div>
        </div>

        {/* Enquiry sidebar */}
        <aside className="detail-enquiry">
          <div className="form-title"><span>01</span><h3>Enquire about {property.name}</h3></div>

          {enquiryStatus === 'success' ? (
            <div className="form-success">
              <Check size={22} /><h3>Thank you.</h3>
              <p>Your enquiry about {property.name} has been received. Our advisory team will be in touch personally.</p>
              <button type="button" className="text-link" onClick={() => { setEnquiryStatus('idle'); setEnquiry({ name: '', phone: '', email: '', message: '', company: '' }); }}>Send another enquiry <ArrowRight size={15} /></button>
            </div>
          ) : (
            <form className="enquiry-form detail-enquiry-form" onSubmit={handleEnquirySubmit} noValidate>
              <label htmlFor="enq-name">Your name<input id="enq-name" name="name" required value={enquiry.name} onChange={(e) => updateEnquiry('name', e.target.value)} placeholder="Full name" autoComplete="name" /></label>
              <div className="form-row">
                <label htmlFor="enq-phone">Phone<input id="enq-phone" name="phone" type="tel" required value={enquiry.phone} onChange={(e) => updateEnquiry('phone', e.target.value)} placeholder="+91" autoComplete="tel" /></label>
                <label htmlFor="enq-email">Email<input id="enq-email" name="email" type="email" required value={enquiry.email} onChange={(e) => updateEnquiry('email', e.target.value)} placeholder="you@email.com" autoComplete="email" /></label>
              </div>
              <label htmlFor="enq-message">Your message<textarea id="enq-message" name="message" value={enquiry.message} onChange={(e) => updateEnquiry('message', e.target.value)} rows={4} maxLength={2000} /></label>

              <input type="text" name="company" value={enquiry.company} onChange={(e: ChangeEvent<HTMLInputElement>) => updateEnquiry('company', e.target.value)} tabIndex={-1} autoComplete="off" aria-hidden="true" style={{ position: 'absolute', left: '-9999px', width: 1, height: 1, opacity: 0 }} />

              {enquiryStatus === 'error' && (
                <div className="form-error" role="alert">
                  {enquiryError}
                  {!CONTACT_ENDPOINT && (
                    <span className="form-error-contacts">
                      <a href={contactInfo.phoneHref}><Phone size={14} /> {contactInfo.phone}</a>
                      <a href={socialLinks.whatsapp} aria-label="Chat on WhatsApp"><WhatsAppIcon size={14} /> WhatsApp</a>
                      <a href={`mailto:${contactInfo.email}`}><Mail size={14} /> {contactInfo.email}</a>
                    </span>
                  )}
                </div>
              )}

              <button className="button button-dark" type="submit" disabled={enquiryStatus === 'submitting'}>
                {enquiryStatus === 'submitting' ? <><Loader2 size={16} className="spin" /> Sending...</> : <>Request details <ArrowRight size={16} /></>}
              </button>
            </form>
          )}

          <div className="detail-enquiry-contacts">
            <a href={contactInfo.phoneHref}><Phone size={15} /> {contactInfo.phone}</a>
            <a href={whatsappEnquiryUrl} target="_blank" rel="noopener noreferrer" aria-label="Enquire about this property on WhatsApp"><WhatsAppIcon size={15} /> WhatsApp Enquiry</a>
            <a href={`mailto:${contactInfo.email}`}><Mail size={15} /> {contactInfo.email}</a>
          </div>
        </aside>
      </section>

      {/* Related properties */}
      {related.length > 0 && (
        <section className="section properties-section">
          <div className="section-heading split-heading">
            <div><p className="eyebrow eyebrow-dark">More in {property.location}</p><h2>Related<br /><em>residences.</em></h2></div>
            <Link className="text-link" to="/properties">View all properties <ArrowRight size={16} /></Link>
          </div>
          <div className="property-grid">
            {related.map((rel) => (
              <PropertyCard key={rel.id} property={rel} />
            ))}
          </div>
        </section>
      )}

      {/* Lightbox */}
      {lightboxOpen && (
        <div className="lightbox-backdrop" onClick={closeLightbox} role="presentation">
          <button className="lightbox-close" onClick={closeLightbox} aria-label="Close photo viewer"><X size={24} /></button>
          <button className="lightbox-nav lightbox-nav--prev" onClick={prevLightbox} aria-label="Previous photo"><ArrowLeft size={22} /></button>
          <img src={activeImage} alt={`${property.name} full size photo`} className="lightbox-image" onClick={(e) => e.stopPropagation()} onError={(e) => { e.currentTarget.style.display = 'none'; }} />
          <button className="lightbox-nav lightbox-nav--next" onClick={nextLightbox} aria-label="Next photo"><ArrowRight size={22} /></button>
        </div>
      )}
    </>
  );
}

export default PropertyDetailPage;
