import { ArrowRight, ArrowUpRight } from 'lucide-react';
import { Link } from 'react-router-dom';
import { images, services } from '@/data';
import { useDocumentMeta } from '@/hooks/useDocumentMeta';

function Services() {
  useDocumentMeta({
    title: 'Services',
    description: 'Buy, lease, sell, invest and private viewing advisory services for luxury residential real estate across South Mumbai.',
    path: '/services',
  });
  return (
    <>
      <section className="page-hero">
        <img className="hero-image" src={images.interior} alt="Luxury interior" />
        <div className="hero-overlay" />
        <div className="page-hero-content reveal-up">
          <p className="eyebrow">The Advisory</p>
          <h1>Considered.<br /><em>Personal.</em></h1>
          <p className="hero-copy">From finding a first home to quietly placing a landmark residence, our work is guided by one principle: the right advice changes everything.</p>
        </div>
      </section>

      <section className="section service-section section-dark">
        <div className="services-grid">
          {services.map(({ icon: Icon, title, text, detail }, index) => (
            <article className="service-item service-item--expanded" key={title}>
              <Icon size={25} />
              <span className="service-number">0{index + 1}</span>
              <h3>{title}</h3>
              <p className="service-short">{text}</p>
              <p className="service-detail">{detail}</p>
              <Link className="text-link text-link-light" to="/contact">Enquire <ArrowUpRight size={15} /></Link>
            </article>
          ))}
        </div>
      </section>

      <section className="process-section">
        <div className="process-intro">
          <p className="eyebrow eyebrow-dark">A better way to move</p>
          <h2>From brief<br />to <em>keys.</em></h2>
          <p>Personally managed, from first conversation to the moment you walk through your new front door.</p>
        </div>
        <div className="process-list">
          {[['01', 'Understand', 'We understand your requirements, lifestyle and objectives.'], ['02', 'Curate', 'We shortlist properties that genuinely fit your brief.'], ['03', 'Experience', 'Private viewings and detailed property evaluation.'], ['04', 'Close', 'Negotiation, documentation and transaction support.']].map(([number, title, text]) => (
            <div className="process-step" key={number}>
              <span>{number}</span><div><h3>{title}</h3><p>{text}</p></div><ArrowRight size={18} />
            </div>
          ))}
        </div>
      </section>

      <section className="owner-section section-dark">
        <div><p className="eyebrow">For owners</p><h2>Thinking of selling<br />or leasing your <em>property?</em></h2><p>Position your property with a boutique advisory approach designed to attract serious, qualified buyers and tenants.</p></div>
        <div className="owner-actions"><Link className="button button-gold" to="/contact">List your property <ArrowRight size={16} /></Link><Link className="text-link text-link-light" to="/contact">Speak to an advisor <ArrowRight size={16} /></Link></div>
      </section>
    </>
  );
}

export default Services;
