import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';
import { useDocumentMeta } from '@/hooks/useDocumentMeta';

function NotFound() {
  useDocumentMeta({
    title: 'Page Not Found',
    description: 'The page you were looking for could not be found.',
    noindex: true,
  });

  return (
    <section className="section" style={{ minHeight: '60vh', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', textAlign: 'center' }}>
      <p className="eyebrow eyebrow-dark">404</p>
      <h1 style={{ color: 'var(--ink)', fontSize: 'clamp(48px, 7vw, 96px)' }}>Page not<br /><em>found.</em></h1>
      <p style={{ color: 'var(--muted)', maxWidth: '380px', marginBottom: '32px' }}>The page you were looking for may have moved or no longer exists. Let's get you back on track.</p>
      <Link className="button button-dark" to="/">Return home <ArrowRight size={16} /></Link>
    </section>
  );
}

export default NotFound;
