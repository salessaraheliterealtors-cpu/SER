import { ArrowRight, ArrowUpRight, FolderOpen, ImageOff, Play } from 'lucide-react';
import { useState } from 'react';
import { Link } from 'react-router-dom';
import type { PropertyDetail } from '@/lib/property-detail';

type PropertyCardProps = {
  property: PropertyDetail;
};

function PropertyCard({ property }: PropertyCardProps) {
  const detailPath = `/properties/${property.slug}`;
  const [imageFailed, setImageFailed] = useState(false);
  const showImage = Boolean(property.image) && !imageFailed;

  return (
    <article className="property-card">
      <Link className="property-image-wrap" to={detailPath} aria-label={`View ${property.name} details`}>
        {showImage ? (
          <img
            src={property.image}
            alt={`${property.name} luxury residence in ${property.location}`}
            loading="lazy"
            onError={() => setImageFailed(true)}
          />
        ) : (
          <div className="property-image-placeholder" aria-hidden="true"><ImageOff size={28} /></div>
        )}
        {property.status && <span className="property-badge">{property.status}</span>}
        {property.transactionType && <span className="property-transaction-badge">{property.transactionType}</span>}
        {(property.photoFolderUrl || property.videoLinkUrl) && (
          <span className="property-media-badge">
            {property.photoFolderUrl && <FolderOpen size={12} />}
            {property.videoLinkUrl && <Play size={12} />}
          </span>
        )}
        <span className="view-circle"><ArrowUpRight size={18} /></span>
      </Link>
      <div className="property-info">
        <div className="property-location"><span />{property.location}</div>
        <h3>{property.name}</h3>
        {property.config && <p className="property-config">{property.config}</p>}
        {property.description && <p className="property-description">{property.description}</p>}
        <div className="property-bottom">
          {property.price
            ? <strong>{property.price}</strong>
            : <strong className="property-price-cta">Price on request</strong>}
          <Link to={detailPath}>View residence <ArrowRight size={14} /></Link>
        </div>
      </div>
    </article>
  );
}

export default PropertyCard;
