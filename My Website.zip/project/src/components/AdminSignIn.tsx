import { useState, type FormEvent } from 'react';
import { ArrowRight, Loader2, Lock } from 'lucide-react';
import { supabase, isSupabaseConfigured } from '@/lib/supabase';

function AdminSignIn() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');

  async function handleSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (submitting || !isSupabaseConfigured) return;
    setSubmitting(true);
    setError('');
    const { error: signInError } = await supabase.auth.signInWithPassword({ email: email.trim(), password });
    setSubmitting(false);
    if (signInError) {
      setError('Sign-in failed. Check your email and password and try again.');
      setPassword('');
    }
  }

  if (!isSupabaseConfigured) {
    return (
      <div className="admin-alert admin-alert--error">
        <Lock size={16} />
        <span>Administrator sign-in is unavailable until the database is connected.</span>
      </div>
    );
  }

  return (
    <div className="admin-form-wrap">
      <div className="form-title">
        <span>01</span>
        <h3>Administrator Sign In</h3>
      </div>
      {error && <div className="admin-alert admin-alert--error"><Lock size={16} /> {error}</div>}
      <form className="enquiry-form admin-form" onSubmit={handleSubmit}>
        <div className="form-row">
          <label>Email<input type="email" required autoComplete="username" value={email} onChange={(e) => setEmail(e.target.value)} /></label>
          <label>Password<input type="password" required autoComplete="current-password" value={password} onChange={(e) => setPassword(e.target.value)} /></label>
        </div>
        <div className="admin-form-actions">
          <button className="button button-dark" type="submit" disabled={submitting}>
            {submitting ? <><Loader2 size={16} className="spin" /> Signing in...</> : <>Sign in <ArrowRight size={16} /></>}
          </button>
        </div>
      </form>
    </div>
  );
}

export default AdminSignIn;
