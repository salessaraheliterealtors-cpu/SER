import { useEffect, useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { ArrowRight, Menu, Phone, X } from 'lucide-react';
import { contactInfo, navItems, socialLinks } from '@/data';
import { WhatsAppIcon } from '@/components/WhatsAppIcon';

function ScrollToTop() {
  const { pathname } = useLocation();
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);
  return null;
}

function Header() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => {
    setMenuOpen(false);
  }, [location.pathname]);

  const isHome = location.pathname === '/';
  const headerClass = isHome
    ? `site-header ${scrolled ? 'site-header--scrolled' : ''}`
    : 'site-header site-header--scrolled site-header--solid';

  return (
    <>
      <header className={headerClass}>
        <Link className="wordmark" to="/" aria-label="Sarah Elite Realtors home">
          <img src="/images/Logo.png" alt="Sarah Elite Realtors" className="wordmark-logo" />
          <span className="wordmark-copy">
            <span className="wordmark-main">SARAH ELITE REALTORS</span>
            <span className="wordmark-sub">REAL ESTATE <i>·</i> MUMBAI</span>
          </span>
        </Link>
        <nav className="desktop-nav" aria-label="Primary navigation">
          {navItems.map((item) => (
            <Link key={item.path} to={item.path} className={location.pathname === item.path ? 'nav-active' : ''}>
              {item.label}
            </Link>
          ))}
        </nav>
        <a className="header-phone" href={contactInfo.phoneHref}><Phone size={14} /> {contactInfo.phone}</a>
        <button className="menu-toggle" onClick={() => setMenuOpen(!menuOpen)} aria-label="Toggle navigation menu" aria-expanded={menuOpen}>
          {menuOpen ? <X size={22} /> : <Menu size={22} />}
        </button>
      </header>

      {menuOpen && (
        <div className="mobile-menu">
          <div className="mobile-menu-meta">
            <img src="/images/Logo.png" alt="Sarah Elite Realtors" />
            <span>SARAH ELITE REALTORS · MUMBAI</span>
          </div>
          {navItems.map((item, index) => (
            <Link key={item.path} to={item.path}>
              <span>0{index + 1}</span>{item.label} <ArrowRight size={18} />
            </Link>
          ))}
          <a href={socialLinks.whatsapp} className="mobile-whatsapp" aria-label="Chat with Sarah Elite Realtors on WhatsApp"><WhatsAppIcon size={16} /> Chat on WhatsApp</a>
        </div>
      )}
    </>
  );
}

function Footer() {
  return (
    <footer className="footer section-dark">
      <div className="footer-top">
        <div>
          <img src="/images/Logo.png" alt="Sarah Elite Realtors" className="footer-logo" />
          <div className="footer-firm-name">SARAH ELITE REALTORS</div>
          <p className="footer-tagline">Exceptional Homes.<br /><em>Exceptional Mumbai.</em></p>
        </div>
        <div className="footer-links">
          <div>
            <span className="footer-label">Explore</span>
            <Link to="/properties">Properties</Link>
            <Link to="/services">Services</Link>
            <Link to="/about">About</Link>
            <Link to="/insights">Insights</Link>
            <Link to="/contact">Contact</Link>
          </div>
          <div>
            <span className="footer-label">Connect</span>
            <a href={contactInfo.phoneHref}>{contactInfo.phone}</a>
            <a href={socialLinks.whatsapp} target="_blank" rel="noreferrer" aria-label="Chat with Sarah Elite Realtors on WhatsApp"><WhatsAppIcon size={15} /> WhatsApp</a>
            <a href={`mailto:${contactInfo.email}`}>{contactInfo.email}</a>
          </div>
          <div>
            <span className="footer-label">Follow</span>
            <a href={socialLinks.linkedin} target="_blank" rel="noreferrer">LinkedIn</a>
            <a href={socialLinks.youtube} target="_blank" rel="noreferrer">YouTube</a>
            <a href={socialLinks.facebook} target="_blank" rel="noreferrer">Facebook</a>
            <a href={socialLinks.instagram} target="_blank" rel="noreferrer">Instagram</a>
          </div>
        </div>
      </div>
      <div className="footer-bottom">
        <span>© 2026 Sarah Elite Realtors. All rights reserved.</span>
        <div><Link to="/privacy">Privacy Policy</Link><Link to="/terms">Terms &amp; Conditions</Link><Link to="/disclaimer">Disclaimer</Link></div>
        <span>Trust · Transparency · Results</span>
      </div>
    </footer>
  );
}

function FloatingWhatsApp() {
  return (
    <a className="floating-whatsapp" href={socialLinks.whatsapp} target="_blank" rel="noreferrer" aria-label="Chat with Sarah Elite Realtors on WhatsApp">
      <WhatsAppIcon size={22} /><span>WhatsApp</span>
    </a>
  );
}

export default function Layout({ children }: { children: React.ReactNode }) {
  return (
    <div className="site-shell">
      <ScrollToTop />
      <Header />
      <main>{children}</main>
      <Footer />
      <FloatingWhatsApp />
    </div>
  );
}
