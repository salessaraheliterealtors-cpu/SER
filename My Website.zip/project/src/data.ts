import { CalendarDays, Compass, FileText, Gem, KeyRound, Search } from 'lucide-react';

export type TransactionType = 'Buy' | 'Rent' | 'Sell';

export const images = {
  hero: 'https://images.pexels.com/photos/5414582/pexels-photo-5414582.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  seaLink: 'https://images.pexels.com/photos/38279448/pexels-photo-38279448.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  skyline: 'https://images.pexels.com/photos/10906000/pexels-photo-10906000.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  interior: 'https://images.pexels.com/photos/27059631/pexels-photo-27059631.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  bedroom: 'https://images.pexels.com/photos/39135432/pexels-photo-39135432.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  architecture: 'https://images.pexels.com/photos/4843167/pexels-photo-4843167.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  city: 'https://images.pexels.com/photos/37352236/pexels-photo-37352236.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
};

export const locations = [
  { number: '01', name: 'Lower Parel', line: "Mumbai's new skyline district.", text: 'Flagship towers, premium residences and direct access to Mumbai\u2019s commercial districts.', image: images.city },
  { number: '02', name: 'Worli', line: 'Where Mumbai meets the Arabian Sea.', text: 'Sea-facing residences, iconic developments and exceptional connectivity.', image: images.seaLink },
  { number: '03', name: 'Prabhadevi', line: 'Quiet luxury in the heart of South Mumbai.', text: 'Premium residences, expansive views and a highly sought-after residential address.', image: images.architecture },
  { number: '04', name: 'Mahalaxmi', line: 'Old-world prestige. Modern luxury.', text: "Racecourse-facing residences and some of Mumbai's most distinctive homes.", image: images.skyline },
];

export const services = [
  { icon: Search, title: 'Buy', text: 'Find exceptional homes that match your lifestyle, requirements and investment objectives.', detail: 'From first viewings to final paperwork, we guide you through every step of acquiring a luxury residence in South Mumbai. Our approach begins with understanding your lifestyle and investment objectives, then curating properties that genuinely fit.' },
  { icon: KeyRound, title: 'Lease', text: 'Access premium furnished and unfurnished residences across Mumbai\u2019s prime locations.', detail: 'Whether you need a turnkey furnished home or a long-term lease on an unfurnished residence, we maintain relationships with landlords across all four micro-markets to find the right match quickly and discreetly.' },
  { icon: Gem, title: 'Sell', text: 'Position and market your property discreetly to qualified buyers.', detail: 'We position your property with professional photography, targeted marketing to qualified HNI and NRI buyers, and complete discretion. No public listings until you approve — every viewing is pre-qualified.' },
  { icon: Compass, title: 'Invest', text: 'Identify opportunities with strong location fundamentals and long-term potential.', detail: 'Our investment advisory combines on-the-ground market intelligence with decade-long transaction experience to identify properties with strong appreciation potential across South Mumbai\u2019s evolving micro-markets.' },
  { icon: FileText, title: 'Property Advisory', text: 'Personalised guidance on pricing, negotiations, documentation and transaction strategy.', detail: 'From pricing strategy and negotiation tactics to documentation and transaction structuring, we provide end-to-end advisory that protects your interests and ensures a smooth, informed transaction.' },
  { icon: CalendarDays, title: 'Private Viewings', text: 'Experience selected properties through carefully arranged private appointments.', detail: 'We arrange private, unhurried viewings of selected properties at times that suit you. Every visit is accompanied by detailed property context and neighbourhood insight.' },
];

export const insights = [
  { category: 'Neighbourhood Guides', title: 'Is Worli Still Mumbai\u2019s Most Desirable Luxury Address?', image: images.seaLink, time: '6 min read', excerpt: 'Worli has long been synonymous with Mumbai luxury. We examine whether the neighbourhood still holds its crown amid rapid development across South Mumbai.' },
  { category: 'Market Insights', title: 'Lower Parel vs Worli: Where Should You Buy a Luxury Home?', image: images.city, time: '8 min read', excerpt: 'Two of Mumbai\u2019s most sought-after addresses, each with a distinct character. We break down the factors that should guide your decision.' },
  { category: 'Buying Guide', title: 'The Complete Guide to Buying Luxury Property in South Mumbai', image: images.interior, time: '10 min read', excerpt: 'From understanding micro-markets to navigating documentation, here is everything you need to know before buying a luxury residence in South Mumbai.' },
  { category: 'Luxury Homes', title: 'What Makes a Mumbai Property Truly Premium?', image: images.bedroom, time: '7 min read', excerpt: 'Beyond square footage and location, certain qualities distinguish a genuinely premium residence. We explore what matters most.' },
  { category: 'Investment', title: 'South Mumbai Investment Hotspots for 2026', image: images.architecture, time: '9 min read', excerpt: 'A look at the micro-markets showing the strongest fundamentals for long-term appreciation in the year ahead.' },
  { category: 'Selling Guide', title: 'How to Discreetly Sell a Luxury Property in Mumbai', image: images.skyline, time: '5 min read', excerpt: 'A guide for owners who want to sell or lease their property without public listings, while attracting serious, qualified buyers.' },
];

export const navItems = [
  { label: 'Home', path: '/' },
  { label: 'Properties', path: '/properties' },
  { label: 'Services', path: '/services' },
  { label: 'About', path: '/about' },
  { label: 'Insights', path: '/insights' },
  { label: 'Contact', path: '/contact' },
];

export const socialLinks = {
  whatsapp: 'https://wa.me/9082619659',
  linkedin: 'https://www.linkedin.com/company/sarah-elite-realtors',
  youtube: 'https://www.youtube.com/@SarahEliteRealtors',
  facebook: 'https://www.facebook.com/saraheliterealtors',
  instagram: 'https://www.instagram.com/saraheliterealtors',
};

export const contactInfo = {
  phone: '+91 90826 19659',
  phoneHref: 'tel:+919082619659',
  email: 'info@saraheliterealtors.com',
  location: 'Mumbai, Maharashtra',
};
