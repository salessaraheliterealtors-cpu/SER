import { useEffect } from 'react';

type MetaOptions = {
  title: string;
  description: string;
  path?: string;
  image?: string;
  noindex?: boolean;
};

const SITE_NAME = 'Sarah Elite Realtors';
const BASE_URL = 'https://ser-brown.vercel.app';
const DEFAULT_SHARE_IMAGE = 'https://images.pexels.com/photos/5414582/pexels-photo-5414582.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';

function setMeta(selector: string, attribute: string, content: string) {
  let el = document.head.querySelector<HTMLMetaElement>(selector);
  if (!el) {
    el = document.createElement('meta');
    const [, attr, value] = selector.match(/\[(.+?)="(.+?)"\]/) || [];
    if (attr && value) el.setAttribute(attr, value);
    document.head.appendChild(el);
  }
  el.setAttribute(attribute, content);
}

export function useDocumentMeta({ title, description, path, image, noindex = false }: MetaOptions) {
  useEffect(() => {
    const fullTitle = title === SITE_NAME ? title : `${title} | ${SITE_NAME}`;
    document.title = fullTitle;

    setMeta('meta[name="description"]', 'content', description);
    setMeta('meta[property="og:title"]', 'content', fullTitle);
    setMeta('meta[property="og:description"]', 'content', description);
    setMeta('meta[name="twitter:title"]', 'content', fullTitle);
    setMeta('meta[name="twitter:description"]', 'content', description);

    const canonicalUrl = path ? `${BASE_URL}${path}` : BASE_URL;
    let canonical = document.head.querySelector<HTMLLinkElement>('link[rel="canonical"]');
    if (!canonical) {
      canonical = document.createElement('link');
      canonical.rel = 'canonical';
      document.head.appendChild(canonical);
    }
    canonical.href = canonicalUrl;

    setMeta('meta[property="og:url"]', 'content', canonicalUrl);

    const shareImage = image || DEFAULT_SHARE_IMAGE;
    setMeta('meta[property="og:image"]', 'content', shareImage);
    setMeta('meta[name="twitter:image"]', 'content', shareImage);
    setMeta('meta[property="og:type"]', 'content', image ? 'article' : 'website');

    setMeta('meta[name="robots"]', 'content', noindex ? 'noindex, nofollow' : 'index, follow');

    return () => {
      const fallbackTitle = `${SITE_NAME} | Exceptional Homes. Exceptional Mumbai.`;
      document.title = fallbackTitle;
    };
  }, [title, description, path, image, noindex]);
}
