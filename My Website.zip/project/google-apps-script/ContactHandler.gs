/**
 * Sarah Elite Realtors — Contact Form Enquiry Handler (Web App)
 *
 * PURPOSE
 *   Receives enquiry form submissions from the website and emails them to
 *   info@saraheliterealtors.com. Also logs each enquiry in a
 *   "Contact Enquiries" sheet tab for your records.
 *
 * ARCHITECTURE NOTE
 *   Google Apps Script Web Apps served via ContentService respond through
 *   an HTTP 302 redirect to script.googleusercontent.com. ContentService
 *   does NOT support custom HTTP headers, so CORS Access-Control-* headers
 *   cannot be set on the response. This integration works because the
 *   frontend sends the POST with Content-Type "text/plain;charset=utf-8"
 *   (a "simple request" that does not trigger a CORS preflight), and the
 *   browser follows the redirect and reads the final JSON body. Do NOT
 *   change the frontend Content-Type to application/json — that triggers
 *   a preflight OPTIONS request which Apps Script does not handle, and
 *   the browser will block the response.
 *
 * SETUP (one-time, ~5 minutes)
 *
 *   1. Open the Google Sheet you use for property sync (or a new one).
 *   2. Go to Extensions > Apps Script.
 *   3. If you already pasted the Property Sync script (Code.gs), create a
 *      new file: click the "+" icon > Script. Name it "ContactHandler".
 *      This file uses CONTACT_SHEET_NAME (not SHEET_NAME) so it will NOT
 *      collide with the SHEET_NAME global in Code.gs.
 *   4. Paste this entire file's contents.
 *   5. Set RECIPIENT_EMAIL below (default: info@saraheliterealtors.com).
 *   6. Save (disk icon).
 *   7. Click Deploy > New deployment.
 *   8. Choose type: "Web app".
 *   9. Description: "Sarah Elite Contact Form".
 *  10. Execute as: "Me" (your Google account).
 *  11. Who has access: "Anyone" (required so the public website can POST
 *      without signing in).
 *  12. Click Deploy. Authorise when prompted.
 *  13. Copy the "Web app URL" shown (it ends in /exec).
 *  14. In your Vercel project settings, add an environment variable:
 *        VITE_CONTACT_ENDPOINT = <the URL you copied>
 *  15. Redeploy your website.
 *
 * SPAM PROTECTION
 *   - Honeypot field: the form includes a hidden "company" field. If a bot
 *     fills it, the submission is silently accepted (HTTP 200, no email).
 *   - Rate limiting: each sender email is limited to 1 enquiry per 10
 *     minutes. The rate-limit entry is only stored AFTER the email is
 *     successfully sent, so a failed delivery does not block retries.
 *   - Field validation: name, phone, email and message are validated
 *     server-side. Invalid submissions are rejected with HTTP 400.
 *
 * SECURITY NOTES
 *   - This script runs as YOUR Google account when triggered by a public
 *     POST request. It only sends email to RECIPIENT_EMAIL.
 *   - It does not expose credentials or stack traces to the requester.
 *
 * TESTING
 *   After deployment, test with curl from a terminal:
 *
 *     curl -X POST "<YOUR_WEB_APP_URL>" \
 *       -H "Content-Type: text/plain;charset=utf-8" \
 *       -d '{"name":"Test","phone":"+91 99999 99999","email":"test@example.com","interest":"Buying","message":"Test enquiry","company":""}'
 *
 *   You should receive an email at RECIPIENT_EMAIL within a minute.
 *   Do not go live until this test succeeds end-to-end.
 */

var RECIPIENT_EMAIL = "info@saraheliterealtors.com";
var CONTACT_SHEET_NAME = "Contact Enquiries";
var RATE_LIMIT_MINUTES = 10;

function doPost(e) {
  var payload;
  try {
    payload = JSON.parse(e.postData.contents);
  } catch (err) {
    return jsonOut({ ok: false, error: "Invalid request format." });
  }
  if (!payload || typeof payload !== "object") {
    return jsonOut({ ok: false, error: "Invalid request format." });
  }

  // Honeypot: if "company" is filled, silently accept (bot detected)
  if (payload.company && String(payload.company).trim() !== "") {
    return jsonOut({ ok: true });
  }

  var name = String(payload.name || "").trim();
  var phone = String(payload.phone || "").trim();
  var email = String(payload.email || "").trim();
  var interest = String(payload.interest || "").trim();
  var message = String(payload.message || "").trim();
  var propertyName = String(payload.property_name || "").trim();
  var propertyId = String(payload.property_id || "").trim();
  var propertyUrl = String(payload.property_url || "").trim();

  // Server-side validation
  if (!name || name.length < 2 || name.length > 100) {
    return jsonOut({ ok: false, error: "A valid name is required." });
  }
  if (!phone || !/^[+\d][\d\s-]{6,}$/.test(phone)) {
    return jsonOut({ ok: false, error: "A valid phone number is required." });
  }
  if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    return jsonOut({ ok: false, error: "A valid email address is required." });
  }
  if (message.length > 2000) {
    return jsonOut({ ok: false, error: "Message is too long (max 2000 characters)." });
  }

  // Rate limiting: check BEFORE sending, but only store AFTER success
  var cache = CacheService.getScriptCache();
  var rateKey = "contact_rate_" + email.toLowerCase();
  if (cache.get(rateKey)) {
    return jsonOut({ ok: false, error: "You have already sent an enquiry recently. Please wait a few minutes before trying again." });
  }

  // Build email body
  var subject = "New Website Enquiry — " + name.replace(/[\r\n]+/g, " ");
  var bodyLines = [
    "A new enquiry was submitted on the Sarah Elite Realtors website.",
    "",
    "Name:     " + name,
    "Phone:    " + phone,
    "Email:    " + email,
    "Interest: " + interest
  ];
  if (propertyName) bodyLines.push("Property: " + propertyName);
  if (propertyId) bodyLines.push("Property ID: " + propertyId);
  if (propertyUrl) bodyLines.push("Property URL: " + propertyUrl);
  bodyLines.push("", "Message:", message, "", "---", "Received: " + new Date().toISOString());

  // Send email
  try {
    MailApp.sendEmail(RECIPIENT_EMAIL, subject, bodyLines.join("\n"));
  } catch (mailErr) {
    return jsonOut({ ok: false, error: "We could not send your enquiry at this time. Please contact us directly by phone or WhatsApp." });
  }

  // Only set rate limit AFTER successful delivery
  cache.put(rateKey, "1", RATE_LIMIT_MINUTES * 60);

  // Logged only after delivery so the sheet never lists an enquiry the visitor was told failed
  try {
    logToSheet(name, phone, email, interest, message, propertyName, propertyId, propertyUrl);
  } catch (logErr) {
    Logger.log("Enquiry log failed: " + logErr);
  }

  return jsonOut({ ok: true });
}

function logToSheet(name, phone, email, interest, message, propertyName, propertyId, propertyUrl) {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sheet = ss.getSheetByName(CONTACT_SHEET_NAME);

  if (!sheet) {
    sheet = ss.insertSheet(CONTACT_SHEET_NAME);
    sheet.appendRow(["Timestamp", "Name", "Phone", "Email", "Interest", "Message", "Property", "Property ID", "Property URL"]);
  }

  sheet.appendRow([new Date(), name, phone, email, interest, message, propertyName, propertyId, propertyUrl]);
}

function jsonOut(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}
