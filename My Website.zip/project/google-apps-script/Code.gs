/**
 * Sarah Elite Realtors — Google Sheets to Website Sync
 *
 * SETUP (one-time)
 *
 * 1. In the Properties tab, make sure row 1 has these headers (any order):
 *    Listing ID, name, location, status, price, config, bhk, furnishing,
 *    carpet_area, parking, description, image_url, gallery_urls,
 *    photo_folder, video_link, transaction_type
 * 2. Add the column "Listing ID" if it is missing. The script fills it with
 *    a permanent ID (SER-####) for every new row. Never edit or reuse these IDs.
 * 3. Extensions > Apps Script. Paste this file into Code.gs.
 * 4. Project Settings > Script Properties. Add two properties:
 *      SHEETS_SYNC_URL     the sheets-sync Edge Function URL
 *      SHEETS_SYNC_SECRET  the same value stored as the function secret
 *    Do not paste these values into this file.
 * 5. Save, then reload the spreadsheet. Use "Sync to Website" > "Dry Run" first.
 *
 * BEHAVIOUR
 * - Matches by Listing ID and external_ref only. Never by name or location.
 * - Blank cells never overwrite existing website values.
 * - Nothing is deleted. Removing a row here does not remove the website listing.
 * - Duplicate Listing IDs within one sync are rejected before sending.
 * - Dry Run shows what would happen without changing any database records.
 * - Each row result is shown after the sync.
 */

var SHEET_NAME = "Properties";

var COLUMN_MAP = {
  "name": "name",
  "location": "location",
  "status": "status",
  "price": "price",
  "config": "config",
  "bhk": "bhk",
  "furnishing": "furnishing",
  "carpet_area": "carpet_area",
  "parking": "parking",
  "description": "description",
  "image_url": "image_url",
  "gallery_urls": "gallery_urls",
  "photo_folder": "photo_folder_url",
  "video_link": "video_link_url",
  "transaction_type": "transaction_type",
  "listing id": "listing_id"
};

var MAX_ROWS_PER_REQUEST = 500;
var ID_PREFIX = "SER-";

function onOpen() {
  SpreadsheetApp.getUi()
    .createMenu("Sync to Website")
    .addItem("Dry Run (preview)", "syncDryRun")
    .addSeparator()
    .addItem("Sync Now (live)", "syncToWebsite")
    .addToUi();
}

function syncDryRun() {
  syncToWebsite(true);
}

function syncToWebsite(dryRun) {
  dryRun = dryRun === true;
  var ui = SpreadsheetApp.getUi();
  var props = PropertiesService.getScriptProperties();
  var syncUrl = props.getProperty("SHEETS_SYNC_URL");
  var secret = props.getProperty("SHEETS_SYNC_SECRET");
  if (!syncUrl || !secret) {
    ui.alert("Not configured", "Add SHEETS_SYNC_URL and SHEETS_SYNC_SECRET in Project Settings > Script Properties.", ui.ButtonSet.OK);
    return;
  }

  var sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_NAME);
  if (!sheet) {
    ui.alert("Error", 'No sheet named "' + SHEET_NAME + '". Rename the tab to "Properties".', ui.ButtonSet.OK);
    return;
  }

  var data = sheet.getDataRange().getValues();
  if (data.length < 2) {
    ui.alert("No data", "No property rows found. Add property data starting from row 2.", ui.ButtonSet.OK);
    return;
  }

  // Read headers dynamically — match by name, not by fixed column position
  var headers = data[0].map(function (h) { return String(h).trim().toLowerCase(); });
  var listingIdCol = headers.indexOf("listing id");
  if (listingIdCol === -1) {
    ui.alert("Missing column", 'Add a column named "Listing ID" to row 1, then sync again.', ui.ButtonSet.OK);
    return;
  }
  var nameCol = headers.indexOf("name");
  if (nameCol === -1) {
    ui.alert("Missing column", 'Add a column named "name" to row 1.', ui.ButtonSet.OK);
    return;
  }

  // First pass: validate, collect rows, generate IDs for genuinely new rows
  var generated = [];
  var rows = [];
  var rowNumbers = [];
  var seenIds = {};
  var duplicateErrors = [];

  for (var r = 1; r < data.length; r++) {
    var raw = data[r];
    if (String(raw[nameCol]).trim() === "") continue;

    var listingId = String(raw[listingIdCol] === null || raw[listingIdCol] === undefined ? "" : raw[listingIdCol]).trim();

    if (listingId === "") {
      // Generate a new ID only for genuinely new rows
      listingId = generateNextId(sheet, listingIdCol);
      raw[listingIdCol] = listingId;
      generated.push({ row: r + 1, value: listingId });
    }

    // Detect duplicate IDs within this sheet
    if (seenIds[listingId]) {
      duplicateErrors.push("Row " + (r + 1) + ": duplicate Listing ID " + listingId);
      continue;
    }
    seenIds[listingId] = true;

    var payload = {};
    for (var c = 0; c < headers.length; c++) {
      var field = COLUMN_MAP[headers[c]];
      if (!field) continue;
      var value = String(raw[c] === null || raw[c] === undefined ? "" : raw[c]).trim();
      if (field === "gallery_urls") {
        payload[field] = value.split(/[\n,]/).map(function (s) { return s.trim(); }).filter(function (s) { return s.length > 0; });
      } else {
        payload[field] = value;
      }
    }
    rows.push(payload);
    rowNumbers.push(r + 1);
  }

  // Report duplicate ID errors before sending anything
  if (duplicateErrors.length > 0) {
    var dupMsg = "Duplicate Listing IDs found. Fix these before syncing:\n\n" + duplicateErrors.slice(0, 15).join("\n");
    if (duplicateErrors.length > 15) dupMsg += "\n...and " + (duplicateErrors.length - 15) + " more.";
    dupMsg += "\n\nNothing was sent to the website.";
    ui.alert("Duplicate IDs", dupMsg, ui.ButtonSet.OK);
    return;
  }

  if (rows.length === 0) {
    ui.alert("No data", "No rows with a name were found.", ui.ButtonSet.OK);
    return;
  }
  if (rows.length > MAX_ROWS_PER_REQUEST) {
    ui.alert("Too many rows", "Sync up to " + MAX_ROWS_PER_REQUEST + " rows at a time.", ui.ButtonSet.OK);
    return;
  }

  // Write generated IDs back to the sheet (only for live sync)
  if (!dryRun) {
    for (var g = 0; g < generated.length; g++) {
      sheet.getRange(generated[g].row, listingIdCol + 1).setValue(generated[g].value);
    }
  }

  var response;
  try {
    response = UrlFetchApp.fetch(syncUrl, {
      method: "post",
      contentType: "application/json",
      headers: { "x-sync-secret": secret },
      payload: JSON.stringify({ rows: rows, dry_run: dryRun }),
      muteHttpExceptions: true
    });
  } catch (err) {
    ui.alert("Sync failed", "The website could not be reached. Try again shortly.", ui.ButtonSet.OK);
    return;
  }

  var code = response.getResponseCode();
  if (code === 401) {
    ui.alert("Sync rejected", "The shared secret does not match the website. Check SHEETS_SYNC_SECRET.", ui.ButtonSet.OK);
    return;
  }
  if (code !== 200) {
    ui.alert("Sync failed", "The website returned an error (HTTP " + code + "). Nothing was confirmed as saved.", ui.ButtonSet.OK);
    return;
  }

  var result = JSON.parse(response.getContentText());
  var errorLines = [];
  for (var e = 0; e < result.results.length; e++) {
    var item = result.results[e];
    if (item.action === "error") {
      var sheetRow = rowNumbers[item.row_number - 1];
      errorLines.push("Row " + sheetRow + ": " + item.message);
    }
  }

  var prefix = dryRun ? "DRY RUN PREVIEW\n\n" : "";
  var summary =
    prefix +
    "Would add: " + (dryRun ? result.summary.inserted : "0") + (dryRun ? "" : "\nAdded: " + result.summary.inserted) +
    "\n" + (dryRun ? "Would update: " + result.summary.updated : "Updated: " + result.summary.updated) +
    "\nErrors: " + result.summary.errors +
    "\nDeleted: 0 (sync never deletes)";
  if (errorLines.length > 0) {
    summary += "\n\n" + errorLines.slice(0, 15).join("\n");
    if (errorLines.length > 15) summary += "\n...and " + (errorLines.length - 15) + " more.";
  }
  if (!dryRun && !result.log_saved) summary += "\n\nThe sync log could not be saved on the website.";
  if (dryRun && generated.length > 0) {
    summary += "\n\n" + generated.length + " new Listing ID(s) would be generated. IDs are only written to the sheet during a live sync.";
  }
  ui.alert(
    dryRun ? "Dry Run Preview" : (result.ok ? "Sync complete" : "Sync finished with errors"),
    summary,
    ui.ButtonSet.OK
  );
}

/**
 * Generates the next sequential SER-#### ID by scanning existing IDs in the sheet.
 */
function generateNextId(sheet, listingIdCol) {
  var lastRow = sheet.getLastRow();
  if (lastRow < 2) return ID_PREFIX + "1001";

  var values = sheet.getRange(2, listingIdCol + 1, lastRow - 1, 1).getValues();
  var maxNum = 1000;
  for (var i = 0; i < values.length; i++) {
    var id = String(values[i][0] || "").trim();
    var match = id.match(/^SER-(\d+)$/);
    if (match) {
      var num = parseInt(match[1], 10);
      if (num > maxNum) maxNum = num;
    }
  }
  return ID_PREFIX + (maxNum + 1);
}
