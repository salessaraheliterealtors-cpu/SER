import { assignSlugs } from '../src/lib/slug';
import { isAvailableStatus } from '../src/lib/availability';

declare const process: { env: Record<string, string | undefined> };

export const config = { runtime: 'edge' };

const BASE_URL = 'https://ser-brown.vercel.app';

const STATIC_PAGES: { path: string; changefreq: string; priority: string }[] = [
  { path: '/', changefreq: 'weekly', priority: '1.0' },
  { path: '/properties', changefreq: 'weekly', priority: '0.9' },
  { path: '/services', changefreq: 'monthly', priority: '0.8' },
  { path: '/about', changefreq: 'monthly', priority: '0.7' },
  { path: '/insights', changefreq: 'monthly', priority: '0.6' },
  { path: '/contact', changefreq: 'yearly', priority: '0.6' },
  { path: '/privacy', changefreq: 'yearly', priority: '0.3' },
  { path: '/terms', changefreq: 'yearly', priority: '0.3' },
  { path: '/disclaimer', changefreq: 'yearly', priority: '0.3' },
];

type ListingRow = { id: string; name: string; location: string; status: string; updated_at: string; slug: string };

type SitemapEntry = { path: string; lastmod?: string; changefreq: string; priority: string };

async function fetchAvailableListings(): Promise<ListingRow[] | null> {
  const url = process.env.VITE_SUPABASE_URL;
  const anonKey = process.env.VITE_SUPABASE_ANON_KEY;
  if (!url || !anonKey) return null;
  try {
    const response = await fetch(`${url}/rest/v1/properties?select=id,name,location,status,updated_at&order=created_at.desc`, {
      headers: { apikey: anonKey, Authorization: `Bearer ${anonKey}` },
    });
    if (!response.ok) return null;
    const data: unknown = await response.json();
    if (!Array.isArray(data)) return null;
    const rows = data.filter(
      (row): row is Omit<ListingRow, 'slug'> =>
        typeof row?.id === 'string' &&
        typeof row?.name === 'string' &&
        typeof row?.location === 'string' &&
        typeof row?.status === 'string',
    );
    const slugs = assignSlugs(rows);
    return rows.map((row, index) => ({ ...row, slug: slugs[index] })).filter((row) => isAvailableStatus(row.status));
  } catch {
    return null;
  }
}

function buildEntries(listings: ListingRow[]): SitemapEntry[] {
  const seen = new Set<string>(STATIC_PAGES.map((page) => page.path));
  const propertyEntries: SitemapEntry[] = [];
  for (const row of listings) {
    const path = `/properties/${row.slug}`;
    if (seen.has(path)) continue;
    seen.add(path);
    propertyEntries.push({
      path,
      lastmod: row.updated_at ? row.updated_at.slice(0, 10) : undefined,
      changefreq: 'monthly',
      priority: '0.8',
    });
  }
  return [...STATIC_PAGES, ...propertyEntries];
}

function toXml(entries: SitemapEntry[]): string {
  const urls = entries
    .map((entry) => {
      const lastmod = entry.lastmod ? `<lastmod>${entry.lastmod}</lastmod>` : '';
      return `  <url><loc>${BASE_URL}${entry.path}</loc>${lastmod}<changefreq>${entry.changefreq}</changefreq><priority>${entry.priority}</priority></url>`;
    })
    .join('\n');
  return `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${urls}\n</urlset>\n`;
}

export default async function handler(): Promise<Response> {
  const listings = (await fetchAvailableListings()) ?? [];
  return new Response(toXml(buildEntries(listings)), {
    headers: {
      'Content-Type': 'application/xml; charset=utf-8',
      'Cache-Control': 'public, s-maxage=300, stale-while-revalidate=3600',
    },
  });
}
