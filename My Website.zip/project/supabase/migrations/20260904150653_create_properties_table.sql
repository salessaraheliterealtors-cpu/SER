/*
# Create properties table and storage bucket for property media

1. New Tables
- `properties`
  - `id` (uuid, primary key)
  - `name` (text, not null) — property/building name
  - `location` (text, not null) — neighbourhood in Mumbai
  - `status` (text) — e.g. Featured, Exclusive, New, Private Listing
  - `config` (text) — e.g. "3 & 4 BHK · Furnished"
  - `bhk` (text) — e.g. "3 & 4 BHK" (used for filtering)
  - `furnishing` (text) — e.g. Fully Furnished, Semi-Furnished, Unfurnished
  - `carpet_area` (text) — e.g. "1,800–2,400 sq ft"
  - `parking` (text) — e.g. "2 Covered"
  - `description` (text) — short description
  - `price` (text) — e.g. "₹ 8.25 Cr onwards" or "Price on Request"
  - `image_url` (text) — main hero image URL
  - `gallery_urls` (text[]) — array of additional photo URLs
  - `video_url` (text) — optional video URL
  - `created_at` (timestamp)
  - `updated_at` (timestamp)

2. Storage
- Creates a public storage bucket `property-media` for photos and videos.
- Adds storage policies allowing anon+authenticated to upload/read/delete.

3. Security
- Enable RLS on `properties`.
- Allow anon + authenticated full CRUD (single-tenant, no auth app — data is intentionally public).
*/

CREATE TABLE IF NOT EXISTS properties (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  location text NOT NULL,
  status text DEFAULT 'Featured',
  config text DEFAULT '',
  bhk text DEFAULT '',
  furnishing text DEFAULT '',
  carpet_area text DEFAULT '',
  parking text DEFAULT '',
  description text DEFAULT '',
  price text DEFAULT 'Price on Request',
  image_url text DEFAULT '',
  gallery_urls text[] DEFAULT '{}',
  video_url text DEFAULT '',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE properties ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_properties" ON properties;
CREATE POLICY "anon_select_properties" ON properties FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_properties" ON properties;
CREATE POLICY "anon_insert_properties" ON properties FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_properties" ON properties;
CREATE POLICY "anon_update_properties" ON properties FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_properties" ON properties;
CREATE POLICY "anon_delete_properties" ON properties FOR DELETE
  TO anon, authenticated USING (true);

-- Auto-update updated_at on row change
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS properties_updated_at ON properties;
CREATE TRIGGER properties_updated_at BEFORE UPDATE ON properties
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

-- Storage bucket for property media (photos + videos)
INSERT INTO storage.buckets (id, name, public)
VALUES ('property-media', 'property-media', true)
ON CONFLICT (id) DO NOTHING;

-- Storage policies: allow anon+authenticated to read, upload, and delete in property-media bucket
DROP POLICY IF EXISTS "read_property_media" ON storage.objects;
CREATE POLICY "read_property_media" ON storage.objects FOR SELECT
  TO anon, authenticated USING (bucket_id = 'property-media');

DROP POLICY IF EXISTS "upload_property_media" ON storage.objects;
CREATE POLICY "upload_property_media" ON storage.objects FOR INSERT
  TO anon, authenticated WITH CHECK (bucket_id = 'property-media');

DROP POLICY IF EXISTS "update_property_media" ON storage.objects;
CREATE POLICY "update_property_media" ON storage.objects FOR UPDATE
  TO anon, authenticated USING (bucket_id = 'property-media') WITH CHECK (bucket_id = 'property-media');

DROP POLICY IF EXISTS "delete_property_media" ON storage.objects;
CREATE POLICY "delete_property_media" ON storage.objects FOR DELETE
  TO anon, authenticated USING (bucket_id = 'property-media');
