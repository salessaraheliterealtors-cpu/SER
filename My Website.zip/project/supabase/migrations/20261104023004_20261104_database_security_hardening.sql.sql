/*
# Database security hardening (Migration B)

1. Properties table — remove anonymous write access
- RLS remains enabled.
- Drops the existing INSERT, UPDATE and DELETE policies that allowed anon + authenticated full write access.
- Keeps the existing SELECT policy so public visitors can read available listings.
- Revokes INSERT, UPDATE and DELETE table privileges from anon and authenticated.
- Grants SELECT only to anon and authenticated (public read).
- service_role retains full access (used by the sync edge function with the service-role key).
- No new write policies are created. Admin editing stays disabled until proper authentication is implemented.

2. Storage — remove anonymous upload/update/delete on property-media bucket
- Drops the upload (INSERT), update (UPDATE) and delete (DELETE) storage policies for the property-media bucket.
- Keeps the read (SELECT) policy so existing public images remain visible.
- Revokes INSERT, UPDATE and DELETE on storage.objects from anon and authenticated.
- Grants SELECT on storage.objects to anon and authenticated so public image viewing continues.
- The 46 existing files are not deleted, moved or renamed.
- Unrelated storage buckets and system policies are not touched.

3. Security notes
- Public visitors can still read property listings and view property images.
- Anonymous uploads, edits and deletions are blocked at both the policy and table-privilege level.
- No fake admin account is created.
- No existing data is deleted or modified.
*/

-- ===== properties table hardening =====

DROP POLICY IF EXISTS "anon_insert_properties" ON public.properties;
DROP POLICY IF EXISTS "anon_update_properties" ON public.properties;
DROP POLICY IF EXISTS "anon_delete_properties" ON public.properties;

REVOKE INSERT, UPDATE, DELETE ON public.properties FROM anon, authenticated;
GRANT SELECT ON public.properties TO anon, authenticated;

-- ===== storage.objects hardening (property-media bucket only) =====

DROP POLICY IF EXISTS "upload_property_media" ON storage.objects;
DROP POLICY IF EXISTS "update_property_media" ON storage.objects;
DROP POLICY IF EXISTS "delete_property_media" ON storage.objects;

REVOKE INSERT, UPDATE, DELETE ON storage.objects FROM anon, authenticated;
GRANT SELECT ON storage.objects TO anon, authenticated;
