/*
# Inventory sync readiness (Migration A)

1. Changes to properties
- Adds `external_ref` (text, nullable) — holds the Listing ID from the Google Sheet (e.g. SER-1001).
- Adds `transaction_type` (text, nullable) — Buy, Rent or Sell only. Never auto-populated.
- Adds a CHECK constraint enforcing transaction_type to be NULL or one of Buy/Rent/Sell.
- Adds a unique partial index on external_ref so the same Listing ID cannot be saved twice. NULL values are ignored, allowing manually added rows without an ID.

2. New table sync_log
- Records each sheet sync run: source, row counts (total, inserted, updated, errors) and per-row results as JSON.
- Columns: id (uuid PK), source, total_rows, inserted, updated, errors, results (jsonb), created_at.
- RLS enabled. ALL privileges revoked from PUBLIC, anon and authenticated.
- Only service_role gets SELECT and INSERT — the sync edge function uses the service-role key.

3. Security notes
- No backfill. The properties table is currently empty (dummy records removed).
- Existing columns photo_folder_url and video_link_url are already present and are not changed.
- No rows are deleted or modified.
- No default value is set for transaction_type.
- If an existing properties_transaction_type_check constraint is found with a mismatched definition, the migration raises an exception and stops.
*/

ALTER TABLE public.properties ADD COLUMN IF NOT EXISTS external_ref text;

ALTER TABLE public.properties ADD COLUMN IF NOT EXISTS transaction_type text;

DO $$
DECLARE
  existing_def text;
BEGIN
  SELECT pg_get_constraintdef(c.oid)
    INTO existing_def
  FROM pg_constraint c
  JOIN pg_class t ON t.oid = c.conrelid
  JOIN pg_namespace n ON n.oid = t.relnamespace
  WHERE n.nspname = 'public'
    AND t.relname = 'properties'
    AND c.conname = 'properties_transaction_type_check';

  IF existing_def IS NOT NULL THEN
    IF existing_def NOT LIKE '%Buy%' OR existing_def NOT LIKE '%Rent%' OR existing_def NOT LIKE '%Sell%' THEN
      RAISE EXCEPTION 'Existing properties_transaction_type_check has an unexpected definition: %', existing_def;
    END IF;
  ELSE
    ALTER TABLE public.properties
      ADD CONSTRAINT properties_transaction_type_check
      CHECK (transaction_type IS NULL OR transaction_type IN ('Buy', 'Rent', 'Sell'));
  END IF;
END $$;

CREATE UNIQUE INDEX IF NOT EXISTS properties_external_ref_key
  ON public.properties (external_ref)
  WHERE external_ref IS NOT NULL;

CREATE TABLE IF NOT EXISTS public.sync_log (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  source text NOT NULL DEFAULT 'google_sheets',
  total_rows integer NOT NULL DEFAULT 0,
  inserted integer NOT NULL DEFAULT 0,
  updated integer NOT NULL DEFAULT 0,
  errors integer NOT NULL DEFAULT 0,
  results jsonb NOT NULL DEFAULT '[]'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.sync_log ENABLE ROW LEVEL SECURITY;

REVOKE ALL ON public.sync_log FROM PUBLIC, anon, authenticated;
GRANT SELECT, INSERT ON public.sync_log TO service_role;
