/*
# Add photo_folder_url column to properties table

1. Modified Tables
- `properties`
  - Added `photo_folder_url` (text) — stores a Google Drive folder link for property photos
  - Added `video_link_url` (text) — stores a Google Drive video link or YouTube link

2. Notes
- These columns allow syncing from Google Sheets where the user pastes Drive links
- The existing `image_url`, `gallery_urls`, and `video_url` columns remain for direct uploads via the admin panel
- The new columns are optional and default to empty string
*/

ALTER TABLE properties ADD COLUMN IF NOT EXISTS photo_folder_url text DEFAULT '';
ALTER TABLE properties ADD COLUMN IF NOT EXISTS video_link_url text DEFAULT '';
