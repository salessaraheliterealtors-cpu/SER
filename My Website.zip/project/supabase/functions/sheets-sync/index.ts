const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });

const MAX_ROWS = 500;
const TRANSACTION_TYPES = ["Buy", "Rent", "Sell"];
const LISTING_ID_PATTERN = /^[A-Za-z0-9_-]{1,64}$/;
const TEXT_FIELDS = [
  "status",
  "price",
  "config",
  "bhk",
  "furnishing",
  "carpet_area",
  "parking",
  "description",
  "image_url",
  "photo_folder_url",
  "video_link_url",
] as const;

type SheetRow = {
  listing_id: string;
  name: string;
  location: string;
  transaction_type: string;
  gallery_urls: string[];
  [field: string]: string | string[];
};

type RowResult = {
  row_number: number;
  listing_id: string | null;
  action: "inserted" | "updated" | "error";
  message: string;
};

function safeEqual(a: string, b: string): boolean {
  const enc = new TextEncoder();
  const x = enc.encode(a);
  const y = enc.encode(b);
  const length = Math.max(x.length, y.length);
  let diff = x.length ^ y.length;
  for (let i = 0; i < length; i++) diff |= (x[i] ?? 0) ^ (y[i] ?? 0);
  return diff === 0;
}

function text(value: unknown, max: number): string {
  return typeof value === "string" ? value.trim().slice(0, max) : "";
}

function isHttpsUrl(value: string): boolean {
  if (!value) return true;
  try {
    return new URL(value).protocol === "https:";
  } catch {
    return false;
  }
}

function sanitiseRow(raw: Record<string, unknown>): { row: SheetRow | null; error: string | null } {
  const row: SheetRow = {
    listing_id: text(raw.listing_id, 64),
    name: text(raw.name, 150),
    location: text(raw.location, 150),
    transaction_type: text(raw.transaction_type, 10),
    gallery_urls: Array.isArray(raw.gallery_urls)
      ? raw.gallery_urls.map((u) => text(u, 2000)).filter((u) => u.length > 0).slice(0, 50)
      : [],
  };
  for (const field of TEXT_FIELDS) row[field] = text(raw[field], field === "description" ? 2000 : 500);

  if (!row.listing_id) return { row: null, error: "Listing ID is missing." };
  if (!LISTING_ID_PATTERN.test(row.listing_id)) return { row: null, error: "Listing ID has invalid characters." };
  if (!row.name) return { row: null, error: "Name is required." };
  if (!row.location) return { row: null, error: "Location is required." };
  if (row.transaction_type && !TRANSACTION_TYPES.includes(row.transaction_type)) {
    return { row: null, error: "Transaction type must be Buy, Rent or Sell." };
  }
  if (!isHttpsUrl(row.image_url) || !isHttpsUrl(row.photo_folder_url) || !isHttpsUrl(row.video_link_url)) {
    return { row: null, error: "Image and link fields must be https addresses." };
  }
  if (row.gallery_urls.some((u) => !isHttpsUrl(u))) return { row: null, error: "Gallery entries must be https addresses." };
  return { row, error: null };
}

function changedFields(row: SheetRow): Record<string, unknown> {
  const fields: Record<string, unknown> = { name: row.name, location: row.location };
  for (const field of TEXT_FIELDS) if (row[field]) fields[field] = row[field];
  if (row.gallery_urls.length > 0) fields.gallery_urls = row.gallery_urls;
  if (row.transaction_type) fields.transaction_type = row.transaction_type;
  return fields;
}

function restUrl(base: string, table: string, params: Record<string, string>): string {
  return `${base}/rest/v1/${table}?${new URLSearchParams(params).toString()}`;
}

async function findExisting(base: string, headers: Record<string, string>, listingId: string): Promise<string | null> {
  const res = await fetch(restUrl(base, "properties", { external_ref: `eq.${listingId}`, select: "id" }), { headers });
  if (!res.ok) throw new Error(`lookup by listing id failed: ${res.status}`);
  const found = (await res.json()) as { id: string }[];
  if (found.length > 1) throw new Error(`more than one record has listing id ${listingId}`);
  return found[0]?.id ?? null;
}

async function saveRow(
  base: string,
  headers: Record<string, string>,
  row: SheetRow,
  rowNumber: number,
  dryRun: boolean,
): Promise<RowResult> {
  const existingId = await findExisting(base, headers, row.listing_id);

  if (existingId) {
    if (dryRun) {
      return { row_number: rowNumber, listing_id: row.listing_id, action: "updated", message: "Would update (dry run)." };
    }
    const res = await fetch(restUrl(base, "properties", { id: `eq.${existingId}` }), {
      method: "PATCH",
      headers: { ...headers, "Content-Type": "application/json", Prefer: "return=minimal" },
      body: JSON.stringify(changedFields(row)),
    });
    if (!res.ok) throw new Error(`update failed: ${res.status}`);
    return { row_number: rowNumber, listing_id: row.listing_id, action: "updated", message: "Updated." };
  }

  if (dryRun) {
    return { row_number: rowNumber, listing_id: row.listing_id, action: "inserted", message: "Would add (dry run)." };
  }

  const insertFields: Record<string, unknown> = { ...changedFields(row), external_ref: row.listing_id };
  for (const field of TEXT_FIELDS) insertFields[field] = row[field] || null;
  insertFields.transaction_type = row.transaction_type || null;
  insertFields.gallery_urls = row.gallery_urls;
  const res = await fetch(restUrl(base, "properties", {}), {
    method: "POST",
    headers: { ...headers, "Content-Type": "application/json", Prefer: "return=minimal" },
    body: JSON.stringify(insertFields),
  });
  if (!res.ok) throw new Error(`insert failed: ${res.status}`);
  return { row_number: rowNumber, listing_id: row.listing_id, action: "inserted", message: "Added." };
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { status: 200, headers: corsHeaders });
  if (req.method !== "POST") return json({ ok: false, error: "Method not allowed." }, 405);

  const expectedSecret = Deno.env.get("SHEETS_SYNC_SECRET");
  const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
  const supabaseUrl = Deno.env.get("SUPABASE_URL");
  if (!expectedSecret || !serviceKey || !supabaseUrl) {
    console.error("sheets-sync is missing required function secrets");
    return json({ ok: false, error: "Sync is not configured." }, 500);
  }

  const providedSecret = req.headers.get("x-sync-secret") ?? "";
  if (!providedSecret || !safeEqual(providedSecret, expectedSecret)) {
    return json({ ok: false, error: "Unauthorized." }, 401);
  }

  let body: { rows?: unknown; dry_run?: boolean };
  try {
    body = await req.json();
  } catch {
    return json({ ok: false, error: "Request body must be JSON." }, 400);
  }
  if (!Array.isArray(body.rows) || body.rows.length === 0 || body.rows.length > MAX_ROWS) {
    return json({ ok: false, error: `Send between 1 and ${MAX_ROWS} rows.` }, 400);
  }

  const dryRun = body.dry_run === true;
  const base = supabaseUrl.replace(/\/$/, "");
  const headers = { apikey: serviceKey, Authorization: `Bearer ${serviceKey}` };
  const results: RowResult[] = [];
  const seenListingIds = new Set<string>();

  for (let i = 0; i < body.rows.length; i++) {
    const rowNumber = i + 1;
    const raw = body.rows[i];
    if (!raw || typeof raw !== "object") {
      results.push({ row_number: rowNumber, listing_id: null, action: "error", message: "Row is not valid." });
      continue;
    }
    const { row, error } = sanitiseRow(raw as Record<string, unknown>);
    if (!row) {
      results.push({ row_number: rowNumber, listing_id: null, action: "error", message: error ?? "Row is not valid." });
      continue;
    }
    if (seenListingIds.has(row.listing_id)) {
      results.push({ row_number: rowNumber, listing_id: row.listing_id, action: "error", message: "Duplicate Listing ID in this sync. Row skipped." });
      continue;
    }
    seenListingIds.add(row.listing_id);
    try {
      results.push(await saveRow(base, headers, row, rowNumber, dryRun));
    } catch (err) {
      console.error(`sheets-sync row ${rowNumber} failed`, err);
      results.push({ row_number: rowNumber, listing_id: row.listing_id, action: "error", message: "Row could not be saved. Try again." });
    }
  }

  const summary = {
    total_rows: results.length,
    inserted: results.filter((r) => r.action === "inserted").length,
    updated: results.filter((r) => r.action === "updated").length,
    errors: results.filter((r) => r.action === "error").length,
  };

  if (!dryRun) {
    const logRes = await fetch(restUrl(base, "sync_log", {}), {
      method: "POST",
      headers: { ...headers, "Content-Type": "application/json", Prefer: "return=minimal" },
      body: JSON.stringify({ source: "google_sheets", ...summary, results }),
    });
    if (!logRes.ok) console.error("sheets-sync could not write sync_log", logRes.status);
    return json({ ok: summary.errors === 0, dry_run: false, summary, results, log_saved: logRes.ok });
  }

  return json({ ok: summary.errors === 0, dry_run: true, summary, results, log_saved: false });
});
